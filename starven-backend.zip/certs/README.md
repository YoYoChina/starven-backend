把与 m.starven.cn 匹配的证书放在本目录（通配符 *.starven.cn 亦可）：

```
certs/fullchain.pem     # 证书链
certs/privkey.pem       # 私钥
```

然后执行 `./deploy.sh https`（8443 直连模式才需要；推荐用 Halo 前置 nginx 反代 443，证书放在 Halo 那边，本目录可以留空）。

80 端口被 Halo 占用时，可用 Let's Encrypt 的 DNS-01 方式申请证书，详见 `docs/部署与运维.md`。

⚠️ 私钥不要提交到代码仓库，也不要发到群里。
