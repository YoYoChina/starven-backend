#!/usr/bin/env bash
# 星湾躲猫猫 · 网站后端一键部署（Docker CE，纯 API，不含前端）
# 用法： ./deploy.sh         推荐：单容器 8080，配合 nginx-m.starven.cn.conf 反代 443
#        ./deploy.sh https   备选：nginx 终止 TLS，8443 直连
set -euo pipefail
cd "$(dirname "$0")"

MODE="${1:-http}"

if ! command -v docker >/dev/null 2>&1; then
  echo "✗ 未检测到 Docker CE，请先安装 docker-ce 与 docker-compose-plugin"; exit 1
fi
if ! docker compose version >/dev/null 2>&1; then
  echo "✗ 未检测到 docker compose 插件，请安装 docker-compose-plugin"; exit 1
fi

rand() { openssl rand -hex 32 2>/dev/null || python3 -c "import secrets;print(secrets.token_hex(32))"; }
randpw() { openssl rand -base64 24 2>/dev/null | tr -dc 'A-Za-z0-9' | cut -c1-16 || echo "Starven$(date +%s)"; }

if [ ! -f .env ]; then
  SECRET="$(rand)"
  PW="$(randpw)"
  cat > .env <<EOF
# 由 deploy.sh 于 $(date '+%Y-%m-%d %H:%M:%S') 自动生成，请妥善保管
APP_DOMAIN=m.starven.cn
CORS_ORIGINS=*
APP_PORT=8080
HTTPS_PORT=8443
SECRET_KEY=${SECRET}
ADMIN_USER=admin
ADMIN_PASSWORD=${PW}
INVITE_CODE=STARVEN2026
HIDE_MINUTES=30
CHASE_MINUTES=30
EOF
  chmod 600 .env
  echo "✓ 已生成 .env（管理员 admin / 密码见 .env，登录后请立即修改）"
fi

mkdir -p data
DOMAIN="$(grep -E '^APP_DOMAIN=' .env | cut -d= -f2 || echo m.starven.cn)"
APORT="$(grep -E '^APP_PORT=' .env | cut -d= -f2 || echo 8080)"

if [ "$MODE" = "https" ]; then
  if [ ! -f certs/fullchain.pem ] || [ ! -f certs/privkey.pem ]; then
    echo "✗ 缺少证书：请把证书放到 certs/fullchain.pem 与 certs/privkey.pem"
    echo "  证书需匹配 ${DOMAIN}（通配符 *.starven.cn 亦可），可用 Let's Encrypt DNS-01 申请"
    exit 1
  fi
  FILE=docker-compose.https.yml
  HPORT="$(grep -E '^HTTPS_PORT=' .env | cut -d= -f2 || echo 8443)"
  URL="https://${DOMAIN}:${HPORT}"
  echo "→ 8443 直连模式（记得安全组放行 ${HPORT}）"
else
  FILE=docker-compose.yml
  URL="https://${DOMAIN}"
  echo "→ 单容器 API 模式（8080）。请确认已把 nginx-m.starven.cn.conf 装到 Halo 前置 nginx。"
fi

echo "→ 构建并启动容器（$FILE）..."
docker compose -f "$FILE" up -d --build

echo "→ 等待健康检查..."
for i in $(seq 1 20); do
  if curl -fsS "http://127.0.0.1:${APORT}/api/health" >/dev/null 2>&1; then
    break
  fi
  sleep 2
done

echo
echo "=========================================================="
echo "✓ 后端部署完成"
echo "  API 地址：${URL}/api/"
echo "  健康检查：curl ${URL}/api/health"
echo "  管理员账号：$(grep -E '^ADMIN_USER=' .env | cut -d= -f2 || echo admin)"
echo "  管理员密码：见 .env（chmod 600）"
echo "  查看日志：docker compose -f $FILE logs -f"
echo "  停止服务：docker compose -f $FILE down"
echo "----------------------------------------------------------"
echo "  前端不在这里：上传到 GitHub 后由 Pages / APK 跨域调用本地址"
echo "  前端 index.html 的 STARVEN_API_BASE 应为 https://${DOMAIN}"
echo "  跨域来源 CORS_ORIGINS 见 .env（默认 * 可用，建议上线后收紧）"
echo "  端口：对外 443（反代）/ 本机 8080 / 直连备选 8443 / 容器内网 8000"
echo "=========================================================="
