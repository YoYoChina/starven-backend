"""全局配置：全部可通过环境变量覆盖，部署时由 .env 注入。"""
from __future__ import annotations

import os
import secrets
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent          # backend/
PROJECT = ROOT.parent
DATA_DIR = Path(os.getenv("DATA_DIR", str(PROJECT / "data")))
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "starven.db"


def _load_secret() -> str:
    v = os.getenv("SECRET_KEY", "").strip()
    if len(v) >= 16:
        return v
    f = DATA_DIR / ".secret_key"
    if f.exists():
        return f.read_text(encoding="utf-8").strip()
    v = secrets.token_hex(32)
    f.write_text(v, encoding="utf-8")
    try:
        f.chmod(0o600)
    except OSError:
        pass
    return v


SECRET_KEY = _load_secret()
TOKEN_TTL = int(os.getenv("TOKEN_TTL", str(7 * 24 * 3600)))

ADMIN_USERNAME = os.getenv("BOOTSTRAP_ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.getenv("BOOTSTRAP_ADMIN_PASSWORD", "")
ADMIN_DISPLAY = os.getenv("BOOTSTRAP_ADMIN_DISPLAY", "星湾管理员")
INVITE_CODE = os.getenv("BOOTSTRAP_INVITE_CODE", "STARVEN2026")

HIDE_MINUTES = float(os.getenv("HIDE_MINUTES", "30"))
CHASE_MINUTES = float(os.getenv("CHASE_MINUTES", "30"))
TICK_SECONDS = float(os.getenv("TICK_SECONDS", "2"))
RADAR_RANGE_M = float(os.getenv("RADAR_RANGE_M", "30"))
CORS_ORIGINS = [
    o.strip() for o in os.getenv("CORS_ORIGINS", "*").split(",") if o.strip()
]

# 阶段常量
DRAFT, HIDING, CHASING, FINISHED = "draft", "hiding", "chasing", "finished"
CATCHER, HIDER, ASSISTANT, PENDING = "catcher", "hider", "assistant", "pending"
ROLE_CN = {CATCHER: "抓捕者", HIDER: "躲藏者", ASSISTANT: "协助者", PENDING: "待抽签"}
PHASE_CN = {DRAFT: "待开始", HIDING: "躲藏阶段", CHASING: "抓捕阶段", FINISHED: "已结束"}


def now() -> float:
    return time.time()
