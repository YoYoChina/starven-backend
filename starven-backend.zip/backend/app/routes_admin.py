"""管理后台：建比赛、名单、现场抽签、阶段控制、道具球二维码、代确认抓获。"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from . import config as C
from .auth import current_user, require_admin
from .db import conn
from .game import (
    apply_score, create_balls, draw_roles, finish_game, get_game, get_player,
    leaderboard, log_event, maybe_finish, state_for,
)
from .utils import make_game_id, make_join_code, qr_svg
from .ws import hub

router = APIRouter(prefix="/api/admin", tags=["管理后台"])


class GameIn(BaseModel):
    name: str = Field(default="第一期趣味躲猫猫比赛", max_length=60)
    center_lat: float = Field(..., ge=-90, le=90)
    center_lng: float = Field(..., ge=-180, le=180)
    radius_m: float = Field(default=150, ge=20, le=5000)
    hide_minutes: float = Field(default=30, ge=0.1, le=180)
    chase_minutes: float = Field(default=30, ge=0.1, le=180)


class PlayerIn(BaseModel):
    username: str


class RoleIn(BaseModel):
    user_id: int
    role: str


class BallsIn(BaseModel):
    count: int = Field(default=20, ge=1, le=200)


class CatchIn(BaseModel):
    hider_id: int
    catcher_id: int | None = None


def _admin(user: dict) -> dict:
    return require_admin(user)


@router.get("/overview")
def overview(user: dict = Depends(current_user)):
    _admin(user)
    with conn() as c:
        users = c.execute("SELECT COUNT(*) n FROM users").fetchone()["n"]
        games = c.execute("SELECT COUNT(*) n FROM games").fetchone()["n"]
        g = c.execute("SELECT * FROM games ORDER BY created_at DESC LIMIT 1").fetchone()
        invites = c.execute("SELECT COUNT(*) n FROM invites WHERE used_by IS NULL").fetchone()["n"]
        data = state_for(c, g["id"], user) if g else None
    return {
        "users": users, "games": games, "unused_invites": invites,
        "current_game": data,
        "online_sockets": hub.presence(g["id"]) if g else 0,
    }


@router.post("/games")
async def create_game(body: GameIn, user: dict = Depends(current_user)):
    _admin(user)
    gid = make_game_id()
    with conn() as c:
        c.execute(
            "INSERT INTO games(id,name,join_code,status,hide_minutes,chase_minutes,center_lat,"
            "center_lng,radius_m,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (gid, body.name.strip(), make_join_code(), C.DRAFT, body.hide_minutes,
             body.chase_minutes, body.center_lat, body.center_lng, body.radius_m,
             user["id"], C.now()),
        )
        row = c.execute("SELECT * FROM games WHERE id=?", (gid,)).fetchone()
    await hub.broadcast(gid, {"type": "refresh"})
    return {"ok": True, "game": dict(row)}


@router.get("/games")
def list_games(user: dict = Depends(current_user)):
    _admin(user)
    with conn() as c:
        rows = c.execute("SELECT * FROM games ORDER BY created_at DESC").fetchall()
    return {"items": [dict(r) for r in rows]}


@router.get("/games/{game_id}")
def game_detail(game_id: str, user: dict = Depends(current_user)):
    _admin(user)
    with conn() as c:
        return state_for(c, game_id, user)


@router.get("/games/{game_id}/players")
def players(game_id: str, user: dict = Depends(current_user)):
    _admin(user)
    with conn() as c:
        get_game(c, game_id)
        rows = c.execute(
            "SELECT gp.*, u.username, u.display_name FROM game_players gp "
            "JOIN users u ON u.id=gp.user_id WHERE gp.game_id=? ORDER BY gp.joined_at",
            (game_id,),
        ).fetchall()
    return {"items": [dict(r) for r in rows], "count": len(rows)}


@router.post("/games/{game_id}/players")
async def add_player(game_id: str, body: PlayerIn, user: dict = Depends(current_user)):
    _admin(user)
    with conn() as c:
        g = get_game(c, game_id)
        if g["status"] == C.FINISHED:
            raise HTTPException(status_code=400, detail="比赛已结束")
        u = c.execute("SELECT * FROM users WHERE username=?", (body.username.strip(),)).fetchone()
        if not u:
            raise HTTPException(status_code=404, detail="用户不存在，请先让对方注册")
        if get_player(c, game_id, u["id"]):
            return {"ok": True, "detail": "已在名单中"}
        c.execute(
            "INSERT INTO game_players(game_id,user_id,role,alive,score,joined_at) VALUES(?,?,?,1,0,?)",
            (game_id, u["id"], C.PENDING, C.now()),
        )
        n = c.execute("SELECT COUNT(*) n FROM game_players WHERE game_id=?", (game_id,)).fetchone()["n"]
    await hub.broadcast(game_id, {"type": "refresh"})
    return {"ok": True, "count": n, "display_name": u["display_name"]}


@router.delete("/games/{game_id}/players/{user_id}")
def remove_player(game_id: str, user_id: int, user: dict = Depends(current_user)):
    _admin(user)
    with conn() as c:
        g = get_game(c, game_id)
        if g["status"] != C.DRAFT:
            raise HTTPException(status_code=400, detail="比赛开始后不能移除成员")
        c.execute("DELETE FROM game_players WHERE game_id=? AND user_id=?", (game_id, user_id))
    return {"ok": True}


@router.post("/games/{game_id}/draw")
async def draw(game_id: str, user: dict = Depends(current_user)):
    _admin(user)
    with conn() as c:
        g = get_game(c, game_id)
        if g["status"] != C.DRAFT:
            raise HTTPException(status_code=400, detail="只能在待开始阶段抽签")
        result = draw_roles(c, game_id)
        log_event(c, game_id, user["id"], "DRAW", "draw", "现场抽签完成")
        summary = {C.ROLE_CN[k]: [x["display_name"] for x in v] for k, v in result.items()}
    await hub.broadcast(game_id, {"type": "draw", "text": "现场抽签完成，快查看你的角色！",
                                  "summary": summary})
    return {"ok": True, "roles": summary,
            "alloc": {"抓捕者": len(result[C.CATCHER]), "躲藏者": len(result[C.HIDER]),
                      "协助者": len(result[C.ASSISTANT])}}


@router.patch("/games/{game_id}/role")
async def set_role(game_id: str, body: RoleIn, user: dict = Depends(current_user)):
    _admin(user)
    if body.role not in (C.CATCHER, C.HIDER, C.ASSISTANT, C.PENDING):
        raise HTTPException(status_code=400, detail="未知角色")
    with conn() as c:
        get_game(c, game_id)
        if not get_player(c, game_id, body.user_id):
            raise HTTPException(status_code=404, detail="成员不在名单中")
        c.execute("UPDATE game_players SET role=? WHERE game_id=? AND user_id=?",
                  (body.role, game_id, body.user_id))
    await hub.broadcast(game_id, {"type": "refresh"})
    return {"ok": True}


@router.post("/games/{game_id}/start")
async def start(game_id: str, user: dict = Depends(current_user)):
    _admin(user)
    with conn() as c:
        g = get_game(c, game_id)
        if g["status"] != C.DRAFT:
            raise HTTPException(status_code=400, detail="比赛已经开始了")
        n = c.execute("SELECT COUNT(*) n FROM game_players WHERE game_id=?", (game_id,)).fetchone()["n"]
        pending = c.execute(
            "SELECT COUNT(*) n FROM game_players WHERE game_id=? AND role=?", (game_id, C.PENDING)
        ).fetchone()["n"]
        if n < 14:
            raise HTTPException(status_code=400, detail=f"比赛开启人数需 ≥14 人，当前 {n} 人")
        if pending:
            raise HTTPException(status_code=400, detail=f"还有 {pending} 人未分配角色，请先现场抽签")
        c.execute("UPDATE games SET status=?, phase_started_at=? WHERE id=?",
                  (C.HIDING, C.now(), game_id))
        log_event(c, game_id, user["id"], "START", "phase", "躲藏阶段开始")
    await hub.broadcast(game_id, {"type": "phase", "phase": C.HIDING,
                                  "text": "躲藏阶段开始！30 分钟倒计时已启动"})
    return {"ok": True, "phase": C.HIDING}


@router.post("/games/{game_id}/next-phase")
async def next_phase(game_id: str, user: dict = Depends(current_user)):
    _admin(user)
    with conn() as c:
        g = get_game(c, game_id)
        if g["status"] != C.HIDING:
            raise HTTPException(status_code=400, detail="当前不在躲藏阶段")
        c.execute("UPDATE games SET status=?, phase_started_at=? WHERE id=?",
                  (C.CHASING, C.now(), game_id))
        log_event(c, game_id, user["id"], "NEXT", "phase", "切换至抓捕阶段")
    await hub.broadcast(game_id, {"type": "phase", "phase": C.CHASING,
                                  "text": "抓捕阶段开始！抓捕者出动"})
    return {"ok": True, "phase": C.CHASING}


@router.post("/games/{game_id}/finish")
async def finish(game_id: str, user: dict = Depends(current_user)):
    _admin(user)
    with conn() as c:
        g = get_game(c, game_id)
        if g["status"] == C.FINISHED:
            return {"ok": True, "winner": g["winner"], "detail": "比赛已结束"}
        winner = finish_game(c, game_id)
        log_event(c, game_id, user["id"], "FINISH", "phase", f"管理员提前结束，{winner}")
    await hub.broadcast(game_id, {"type": "game_over", "winner": winner,
                                  "text": "躲藏者获胜 🎉" if winner == "hiders" else "抓捕者获胜 🎯"})
    return {"ok": True, "winner": winner}


@router.post("/games/{game_id}/balls")
def add_balls(game_id: str, body: BallsIn, user: dict = Depends(current_user)):
    _admin(user)
    with conn() as c:
        get_game(c, game_id)
        items = create_balls(c, game_id, body.count)
    for it in items:
        it["svg"] = qr_svg(it["code"])
    return {"ok": True, "items": items, "count": len(items)}


@router.get("/games/{game_id}/balls")
def list_balls(game_id: str, user: dict = Depends(current_user)):
    _admin(user)
    with conn() as c:
        get_game(c, game_id)
        rows = c.execute(
            "SELECT b.*, u.display_name used_by_name FROM balls b LEFT JOIN users u ON u.id=b.used_by "
            "WHERE b.game_id=? ORDER BY b.label LIMIT 200", (game_id,)
        ).fetchall()
    items = []
    for r in rows:
        d = dict(r)
        d["svg"] = qr_svg(d["code"])
        items.append(d)
    return {"items": items, "count": len(items)}


@router.post("/games/{game_id}/catch")
async def catch_by_admin(game_id: str, body: CatchIn, user: dict = Depends(current_user)):
    _admin(user)
    with conn() as c:
        g = get_game(c, game_id)
        if g["status"] != C.CHASING:
            raise HTTPException(status_code=400, detail="仅抓捕阶段可确认抓获")
        h = get_player(c, game_id, body.hider_id)
        if not h or h["role"] != C.HIDER or not h["alive"]:
            raise HTTPException(status_code=400, detail="该玩家不是存活的躲藏者")
        catcher = c.execute(
            "SELECT user_id FROM game_players WHERE game_id=? AND role=? ORDER BY user_id LIMIT 1",
            (game_id, C.CATCHER),
        ).fetchone()
        cid = body.catcher_id or (catcher["user_id"] if catcher else None)
        if not cid:
            raise HTTPException(status_code=400, detail="本场没有抓捕者")
        name = c.execute("SELECT display_name FROM users WHERE id=?", (body.hider_id,)).fetchone()["display_name"]
        c.execute("UPDATE game_players SET alive=0, caught_at=? WHERE game_id=? AND user_id=?",
                  (C.now(), game_id, body.hider_id))
        score = apply_score(c, game_id, cid, 10.0, f"管理员代确认抓获 {name}")
        log_event(c, game_id, cid, f"P-{body.hider_id}", "catch", f"管理员代确认抓获 {name}")
        winner = maybe_finish(c, game_id)
    await hub.broadcast(game_id, {"type": "caught", "text": f"{name} 被抓获（抓捕者 +10 分）",
                                  "target_id": body.hider_id, "catcher": cid})
    if winner:
        await hub.broadcast(game_id, {"type": "game_over", "winner": winner,
                                      "text": "抓捕者获胜 🎯"})
    await hub.broadcast(game_id, {"type": "refresh"})
    return {"ok": True, "score": score, "winner": winner}
