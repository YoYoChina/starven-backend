"""WebSocket 实时通道：按比赛分房间，支持定向推送与按角色脱敏广播。"""
from __future__ import annotations

import asyncio
import json
from typing import Dict, Optional, Set

from fastapi import WebSocket


class Hub:
    def __init__(self) -> None:
        # rooms[game_id][websocket] = {uid, role, is_admin, name}
        self.rooms: Dict[str, Dict[WebSocket, dict]] = {}
        self._lock = asyncio.Lock()

    async def join(self, ws: WebSocket, game_id: str, meta: dict) -> None:
        async with self._lock:
            self.rooms.setdefault(game_id, {})[ws] = meta

    async def leave(self, ws: WebSocket, game_id: str) -> None:
        async with self._lock:
            room = self.rooms.get(game_id)
            if room:
                room.pop(ws, None)
                if not room:
                    self.rooms.pop(game_id, None)

    @staticmethod
    async def send(ws: WebSocket, msg: dict) -> None:
        try:
            await ws.send_text(json.dumps(msg, ensure_ascii=False))
        except Exception:
            pass

    async def broadcast(self, game_id: str, msg: dict) -> None:
        async with self._lock:
            targets = list(self.rooms.get(game_id, {}).keys())
        for ws in targets:
            await self.send(ws, msg)

    async def broadcast_roles(self, game_id: str, roles: Set[str], msg: dict) -> None:
        async with self._lock:
            targets = [
                ws for ws, m in self.rooms.get(game_id, {}).items()
                if m["role"] in roles or m["is_admin"]
            ]
        for ws in targets:
            await self.send(ws, msg)

    async def send_user(self, user_id: int, msg: dict) -> None:
        async with self._lock:
            targets = [
                ws for room in self.rooms.values() for ws, m in room.items()
                if m["uid"] == user_id
            ]
        for ws in targets:
            await self.send(ws, msg)

    def presence(self, game_id: str) -> int:
        return len(self.rooms.get(game_id, {}))


hub = Hub()
