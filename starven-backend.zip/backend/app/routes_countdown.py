"""v2 倒计时接口：成员只读状态，管理员自定义段数 / 模式 / 控制。"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from . import countdown as CD
from .auth import current_user, require_admin
from .db import conn
from .game import get_game, get_player

router = APIRouter(prefix="/api/games", tags=["倒计时"])
admin = APIRouter(prefix="/api/admin/games", tags=["倒计时管理"])


class SegmentIn(BaseModel):
    label: str = Field(..., max_length=20)
    duration: float = Field(..., ge=5, le=21600)


class SegmentsIn(BaseModel):
    segments: list[SegmentIn] = Field(..., min_length=1, max_length=12)


class ModeIn(BaseModel):
    mode: str


def _check_member(c, game_id: str, user: dict) -> None:
    get_game(c, game_id)
    if not user["is_admin"] and not get_player(c, game_id, user["id"]):
        raise HTTPException(status_code=403, detail="请先加入比赛")


@router.get("/{game_id}/countdown")
def countdown_state(game_id: str, user: dict = Depends(current_user)):
    with conn() as c:
        _check_member(c, game_id, user)
        return CD.state_payload(c, game_id)


@admin.get("/{game_id}/countdown")
def admin_countdown(game_id: str, user: dict = Depends(current_user)):
    require_admin(user)
    with conn() as c:
        get_game(c, game_id)
        return {"state": CD.state_payload(c, game_id),
                "settings": CD.get_settings(c, game_id)}


@admin.put("/{game_id}/countdown/segments")
async def replace_segments(game_id: str, body: SegmentsIn, user: dict = Depends(current_user)):
    require_admin(user)
    with conn() as c:
        get_game(c, game_id)
        CD.replace_segments(c, game_id, [x.model_dump() for x in body.segments])
        payload = CD.state_payload(c, game_id)
    await CD.broadcast_state(game_id, {"text": f"倒计时已更新为 {payload['segment_count']} 段"})
    return {"ok": True, "state": payload}


@admin.post("/{game_id}/countdown/segments")
async def add_segment(game_id: str, body: SegmentIn, user: dict = Depends(current_user)):
    require_admin(user)
    with conn() as c:
        get_game(c, game_id)
        CD.add_segment(c, game_id, body.label, body.duration)
        payload = CD.state_payload(c, game_id)
    await CD.broadcast_state(game_id, {"text": f"已添加「{body.label}」"})
    return {"ok": True, "state": payload}


@admin.delete("/{game_id}/countdown/segments/{seg_id}")
async def delete_segment(game_id: str, seg_id: int, user: dict = Depends(current_user)):
    require_admin(user)
    with conn() as c:
        get_game(c, game_id)
        CD.remove_segment(c, game_id, seg_id)
        payload = CD.state_payload(c, game_id)
    await CD.broadcast_state(game_id, {"text": "已删除一段倒计时"})
    return {"ok": True, "state": payload}


@admin.post("/{game_id}/countdown/mode")
async def set_mode(game_id: str, body: ModeIn, user: dict = Depends(current_user)):
    require_admin(user)
    if body.mode not in (CD.SEQUENTIAL, CD.PARALLEL):
        raise HTTPException(status_code=400, detail="模式只能是 sequential 或 parallel")
    with conn() as c:
        get_game(c, game_id)
        CD.reset(c, game_id)
        CD.update_settings(c, game_id, countdown_mode=body.mode)
        payload = CD.state_payload(c, game_id)
    await CD.broadcast_state(game_id, {
        "text": "已切换为「同时显示 · 多段并行」" if body.mode == CD.PARALLEL
                else "已切换为「单独显示 · 依次自动接棒」",
    })
    return {"ok": True, "state": payload}


@admin.post("/{game_id}/countdown/{action}")
async def countdown_action(game_id: str, action: str, user: dict = Depends(current_user)):
    require_admin(user)
    with conn() as c:
        get_game(c, game_id)
        fn = {
            "start": CD.start, "pause": CD.pause, "resume": CD.resume,
            "reset": CD.reset, "next": CD.skip_next,
        }.get(action)
        if not fn:
            raise HTTPException(status_code=400, detail="未知操作")
        result = fn(c, game_id)
        payload = CD.state_payload(c, game_id)
    labels = {"start": "倒计时开始", "pause": "已暂停", "resume": "已继续",
              "reset": "已重置", "next": "已切到下一段"}
    await CD.broadcast_state(game_id, {"text": labels[action], "action": action})
    return {"ok": True, "state": payload, "result": result}
