"""账号体系：PBKDF2 密码哈希 + 自签 JWT（HS256），不依赖外部认证服务。"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import re
import secrets
import time
from typing import Optional

from fastapi import Header, HTTPException

from .config import SECRET_KEY, TOKEN_TTL
from .db import conn

_USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{3,20}$")
_ITERATIONS = 180_000


def new_salt() -> str:
    return secrets.token_hex(16)


def hash_password(password: str, salt: str) -> str:
    return hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), bytes.fromhex(salt), _ITERATIONS
    ).hex()


def verify_password(password: str, salt: str, expected: str) -> bool:
    return hmac.compare_digest(hash_password(password, salt), expected)


def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _unb64(text: str) -> bytes:
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


def make_token(user: dict) -> str:
    header = _b64(json.dumps({"alg": "HS256", "typ": "JWT"}, separators=(",", ":")).encode())
    payload = _b64(json.dumps({
        "uid": user["id"],
        "username": user["username"],
        "adm": int(user["is_admin"]),
        "iat": int(time.time()),
        "exp": int(time.time()) + TOKEN_TTL,
    }, separators=(",", ":")).encode())
    sig = _b64(hmac.new(SECRET_KEY.encode(), f"{header}.{payload}".encode(), hashlib.sha256).digest())
    return f"{header}.{payload}.{sig}"


def parse_token(token: str) -> Optional[dict]:
    try:
        h, p, s = token.split(".")
        expect = _b64(hmac.new(SECRET_KEY.encode(), f"{h}.{p}".encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(s, expect):
            return None
        payload = json.loads(_unb64(p))
        if payload.get("exp", 0) < time.time():
            return None
        return payload
    except Exception:
        return None


def authenticate(authorization: Optional[str]) -> dict:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="请先登录")
    payload = parse_token(authorization[7:].strip())
    if not payload:
        raise HTTPException(status_code=401, detail="登录已失效，请重新登录")
    with conn() as c:
        row = c.execute("SELECT * FROM users WHERE id=?", (payload["uid"],)).fetchone()
    if not row:
        raise HTTPException(status_code=401, detail="账号不存在")
    return dict(row)


def current_user(authorization: Optional[str] = Header(default=None)) -> dict:
    return authenticate(authorization)


def require_admin(user: dict = None) -> dict:
    if user is None:
        raise HTTPException(status_code=401, detail="请先登录")
    if not user["is_admin"]:
        raise HTTPException(status_code=403, detail="仅管理员可执行此操作")
    return user


def check_username(username: str) -> str:
    username = (username or "").strip()
    if not _USERNAME_RE.match(username):
        raise HTTPException(status_code=400, detail="用户名需为 3-20 位字母、数字或下划线")
    return username


def check_password(password: str) -> str:
    if not password or len(password) < 8:
        raise HTTPException(status_code=400, detail="密码至少 8 位")
    return password
