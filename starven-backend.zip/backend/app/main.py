"""应用入口：纯 API 服务（REST + WebSocket + 后台计时引擎）。

前端 PWA 独立部署在 GitHub Pages / Capacitor APK，跨域调用本服务。
若同目录上级存在 frontend/ 目录（本地联调），会顺带挂载静态页。
"""
from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from . import __version__, config as C
from .auth import parse_token
from .countdown import countdown_tick
from .db import conn, init_db
from .game import bootstrap, engine_tick, get_player
from .routes_admin import router as admin_router
from .routes_auth import router as auth_router
from .routes_countdown import admin as countdown_admin_router
from .routes_countdown import router as countdown_router
from .routes_game import router as game_router
from .routes_map import TILE_PRESETS
from .routes_map import admin_router as map_admin_router
from .routes_map import router as map_router
from .ws import hub

FRONTEND = C.PROJECT / "frontend"


async def _tick_loop() -> None:
    while True:
        try:
            events = await asyncio.to_thread(engine_tick)
            events += await asyncio.to_thread(countdown_tick)
            for gid, msg in events:
                await hub.broadcast(gid, msg)
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            print(f"[engine] tick error: {exc}", flush=True)
        await asyncio.sleep(C.TICK_SECONDS)


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    generated = bootstrap()
    if generated:
        print("=" * 58, flush=True)
        print(f"[星湾] 初始管理员密码已生成，请查看 data/初始管理员密码.txt", flush=True)
        print(f"[星湾] 账号 {C.ADMIN_USERNAME} / 密码 {generated}", flush=True)
        print("=" * 58, flush=True)
    task = asyncio.create_task(_tick_loop())
    yield
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        pass


app = FastAPI(
    title="星湾躲猫猫 · 比赛系统",
    description="第一期趣味躲猫猫比赛 APP 后端：账号、扫球、定位、计分、实时广播",
    version=__version__,
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=C.CORS_ORIGINS,
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router)
app.include_router(game_router)
app.include_router(admin_router)
app.include_router(countdown_router)
app.include_router(countdown_admin_router)
app.include_router(map_router)
app.include_router(map_admin_router)


@app.get("/api/health")
def health():
    with conn() as c:
        c.execute("SELECT 1").fetchone()
    return {"ok": True, "version": __version__, "service": "starven-hide-and-seek",
            "db": "sqlite/wal", "edition": "v2-map-countdown", "time": C.now()}


@app.get("/api/meta")
def meta():
    return {
        "version": __version__,
        "studio": "星湾工作室 / Starven Studio",
        "rules": {
            "min_players": 14,
            "role_ratio": "抓捕者1 : 躲藏者10 : 协助者3（人数按比例类推）",
            "hide_minutes": C.HIDE_MINUTES,
            "chase_minutes": C.CHASE_MINUTES,
            "radar_range_m": C.RADAR_RANGE_M,
            "ball_score": 0.5,
            "survive_score": 1,
            "survive_interval_minutes": 5,
            "catch_score": 10,
            "win": "抓捕阶段结束仍有幸存者 → 躲藏者获胜；无幸存者 → 抓捕者获胜",
        },
        "v2": {
            "countdown": "自定义段数（默认 3 段模板）、顺序自动接棒 / 多段同时显示",
            "map": "Leaflet 本地内置 + 全程轨迹 + 双视图（地图 / 雷达）",
            "reveal": "管理员一键公开全员真实定位与轨迹，广播到所有客户端",
            "tiles": TILE_PRESETS,
        },
    }


@app.websocket("/api/ws")
async def websocket_endpoint(ws: WebSocket, token: str = "", game_id: str = ""):
    payload = parse_token(token)
    if not payload:
        await ws.close(code=4401)
        return
    uid = payload["uid"]
    with conn() as c:
        u = c.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
        if not u:
            await ws.close(code=4401)
            return
        gp = get_player(c, game_id, uid) if game_id else None
        # game_id 为空表示「尚未加入比赛」的待机连接，允许连上以便接收后续广播
        if game_id and not gp and not u["is_admin"]:
            await ws.close(code=4403)
            return
        role = gp["role"] if gp else "admin"
        name, is_admin = u["display_name"], bool(u["is_admin"])
    await ws.accept()
    await hub.join(ws, game_id, {"uid": uid, "role": role, "is_admin": is_admin, "name": name})
    await hub.send(ws, {"type": "hello", "text": "实时通道已连接", "role": role,
                        "uid": uid, "version": __version__})
    try:
        while True:
            text = await ws.receive_text()
            if text.strip() in ("ping", "PING"):
                await hub.send(ws, {"type": "pong", "at": C.now()})
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
    finally:
        await hub.leave(ws, game_id)


@app.exception_handler(Exception)
async def unhandled(request, exc):
    # 统一 JSON 错误，避免把堆栈暴露给客户端；完整堆栈写进容器日志
    import traceback
    traceback.print_exc()
    return JSONResponse(status_code=500, content={"detail": "服务器内部错误，请查看容器日志"})


if FRONTEND.exists():
    # 本地单进程调试时也能直接打开 PWA；生产由 nginx 提供静态文件
    app.mount("/", StaticFiles(directory=str(FRONTEND), html=True), name="web")
