"""v2 自定义倒计时：多段可增删，顺序模式一段结束自动启动下一段，
同时模式多段并行；所有时间以服务器时钟为准，前端只做本地插值显示。

模式说明（对应需求「三个倒计时可选择同时显示或单独显示」）：
- sequential 单独显示：只放大当前段，其余段排队；当前段归零后自动启动下一段。
- parallel  同时显示：所有段各自独立倒计时，同屏并列展示（默认给 3 段模板）。
段数不固定为 3，可任意添加 / 删除 / 改名 / 改时长。
"""
from __future__ import annotations

from typing import List, Optional, Tuple

from fastapi import HTTPException

from . import config as C
from .db import conn
from .game import get_game
from .ws import hub

SEQUENTIAL = "sequential"
PARALLEL = "parallel"
IDLE, RUNNING, PAUSED, DONE = "idle", "running", "paused", "done"

DEFAULT_SEGMENTS = [
    {"label": "躲藏时间", "duration": 30 * 60},
    {"label": "抓捕时间", "duration": 30 * 60},
    {"label": "机动 / 收尾", "duration": 10 * 60},
]


# ---------------------------------------------------------------- 设置
def get_settings(c, game_id: str) -> dict:
    row = c.execute("SELECT * FROM game_settings WHERE game_id=?", (game_id,)).fetchone()
    if not row:
        c.execute(
            "INSERT OR IGNORE INTO game_settings(game_id,countdown_mode,reveal_all,map_tiles,updated_at) "
            "VALUES(?,?,0,?,?)", (game_id, SEQUENTIAL, "osm", C.now())
        )
        row = c.execute("SELECT * FROM game_settings WHERE game_id=?", (game_id,)).fetchone()
    return dict(row)


def update_settings(c, game_id: str, **kw) -> dict:
    get_settings(c, game_id)
    allowed = {"countdown_mode", "reveal_all", "map_tiles"}
    for k, v in kw.items():
        if k not in allowed:
            raise HTTPException(status_code=400, detail=f"未知设置项 {k}")
        c.execute(f"UPDATE game_settings SET {k}=?, updated_at=? WHERE game_id=?", (v, C.now(), game_id))
    return get_settings(c, game_id)


# ---------------------------------------------------------------- 段管理
def list_rows(c, game_id: str) -> List[dict]:
    rows = c.execute(
        "SELECT * FROM countdowns WHERE game_id=? ORDER BY seq, id", (game_id,)
    ).fetchall()
    return [dict(r) for r in rows]


def ensure_defaults(c, game_id: str) -> List[dict]:
    rows = list_rows(c, game_id)
    if rows:
        return rows
    for i, seg in enumerate(DEFAULT_SEGMENTS, 1):
        c.execute(
            "INSERT INTO countdowns(game_id,seq,label,duration,status,created_at) VALUES(?,?,?,?,?,?)",
            (game_id, i, seg["label"], seg["duration"], IDLE, C.now()),
        )
    return list_rows(c, game_id)


def replace_segments(c, game_id: str, items: list) -> List[dict]:
    """管理员整体提交段列表：段数自由，默认 3 段只是模板。"""
    if not isinstance(items, list) or not items:
        raise HTTPException(status_code=400, detail="至少需要 1 段倒计时")
    if len(items) > 12:
        raise HTTPException(status_code=400, detail="最多支持 12 段倒计时")
    c.execute("DELETE FROM countdowns WHERE game_id=?", (game_id,))
    for i, it in enumerate(items, 1):
        label = str(it.get("label") or f"第 {i} 段").strip()[:20]
        try:
            duration = float(it.get("duration", 600))
        except (TypeError, ValueError):
            raise HTTPException(status_code=400, detail="时长必须是数字（秒）")
        if not 5 <= duration <= 6 * 3600:
            raise HTTPException(status_code=400, detail="单段时长需在 5 秒 ~ 6 小时之间")
        c.execute(
            "INSERT INTO countdowns(game_id,seq,label,duration,status,created_at) VALUES(?,?,?,?,?,?)",
            (game_id, i, label, duration, IDLE, C.now()),
        )
    return list_rows(c, game_id)


def add_segment(c, game_id: str, label: str, duration: float) -> List[dict]:
    rows = list_rows(c, game_id)
    seq = (rows[-1]["seq"] + 1) if rows else 1
    c.execute(
        "INSERT INTO countdowns(game_id,seq,label,duration,status,created_at) VALUES(?,?,?,?,?,?)",
        (game_id, seq, label[:20] or f"第 {seq} 段", duration, IDLE, C.now()),
    )
    return list_rows(c, game_id)


def remove_segment(c, game_id: str, seg_id: int) -> List[dict]:
    c.execute("DELETE FROM countdowns WHERE game_id=? AND id=?", (game_id, seg_id))
    rows = list_rows(c, game_id)
    for i, r in enumerate(rows, 1):
        c.execute("UPDATE countdowns SET seq=? WHERE id=?", (i, r["id"]))
    return list_rows(c, game_id)


# ---------------------------------------------------------------- 控制
def _start_one(c, row: dict, at: float) -> None:
    c.execute(
        "UPDATE countdowns SET status=?, started_at=?, ends_at=?, remaining=? WHERE id=?",
        (RUNNING, at, at + row["duration"], row["duration"], row["id"]),
    )


def start(c, game_id: str) -> dict:
    st = get_settings(c, game_id)
    rows = ensure_defaults(c, game_id)
    at = C.now()
    # 重置全部
    c.execute(
        "UPDATE countdowns SET status=?,started_at=NULL,ends_at=NULL,remaining=NULL WHERE game_id=?",
        (IDLE, game_id),
    )
    rows = list_rows(c, game_id)
    if st["countdown_mode"] == PARALLEL:
        for r in rows:
            _start_one(c, r, at)
        active = [r["id"] for r in rows]
    else:
        _start_one(c, rows[0], at)
        active = [rows[0]["id"]]
    return {"ok": True, "mode": st["countdown_mode"], "active_ids": active, "at": at}


def pause(c, game_id: str) -> dict:
    at = C.now()
    rows = [r for r in list_rows(c, game_id) if r["status"] == RUNNING]
    for r in rows:
        remain = max(0.0, (r["ends_at"] or at) - at)
        c.execute("UPDATE countdowns SET status=?,remaining=?,ends_at=NULL WHERE id=?",
                  (PAUSED, remain, r["id"]))
    return {"ok": True, "paused": len(rows), "at": at}


def resume(c, game_id: str) -> dict:
    at = C.now()
    rows = [r for r in list_rows(c, game_id) if r["status"] == PAUSED]
    for r in rows:
        remain = r["remaining"] if r["remaining"] is not None else r["duration"]
        c.execute("UPDATE countdowns SET status=?,ends_at=?,remaining=? WHERE id=?",
                  (RUNNING, at + remain, remain, r["id"]))
    return {"ok": True, "resumed": len(rows), "at": at}


def reset(c, game_id: str) -> dict:
    c.execute(
        "UPDATE countdowns SET status=?,started_at=NULL,ends_at=NULL,remaining=NULL WHERE game_id=?",
        (IDLE, game_id),
    )
    return {"ok": True}


def skip_next(c, game_id: str) -> dict:
    """顺序模式下立刻结束当前段并启动下一段（手动提前切换）。"""
    st = get_settings(c, game_id)
    if st["countdown_mode"] != SEQUENTIAL:
        raise HTTPException(status_code=400, detail="同时模式没有「下一段」，请用暂停/重置")
    rows = list_rows(c, game_id)
    cur = next((r for r in rows if r["status"] in (RUNNING, PAUSED)), None)
    if not cur:
        return start(c, game_id)
    c.execute("UPDATE countdowns SET status=?,remaining=0,ends_at=? WHERE id=?",
              (DONE, C.now(), cur["id"]))
    nxt = next((r for r in rows if r["seq"] > cur["seq"] and r["status"] == IDLE), None)
    if nxt:
        _start_one(c, nxt, C.now())
        return {"ok": True, "next_id": nxt["id"], "next_label": nxt["label"]}
    return {"ok": True, "next_id": None, "all_done": True}


# ---------------------------------------------------------------- 状态输出
def state_payload(c, game_id: str) -> dict:
    st = get_settings(c, game_id)
    rows = ensure_defaults(c, game_id)
    at = C.now()
    items = []
    for r in rows:
        if r["status"] == RUNNING and r["ends_at"]:
            remaining = max(0.0, r["ends_at"] - at)
        elif r["status"] == PAUSED:
            remaining = r["remaining"] if r["remaining"] is not None else r["duration"]
        elif r["status"] == DONE:
            remaining = 0.0
        else:
            remaining = r["duration"]
        items.append({
            "id": r["id"], "seq": r["seq"], "label": r["label"],
            "duration": r["duration"], "status": r["status"],
            "remaining": round(remaining, 2), "ends_at": r["ends_at"],
            "started_at": r["started_at"],
        })
    active = [x["id"] for x in items if x["status"] == RUNNING]
    all_done = bool(items) and all(x["status"] == DONE for x in items)
    return {
        "mode": st["countdown_mode"],
        "items": items,
        "active_ids": active,
        "active_id": active[0] if active else None,
        "all_done": all_done,
        "server_now": at,
        "segment_count": len(items),
    }


# ---------------------------------------------------------------- 计时引擎
async def broadcast_state(game_id: str, extra: dict | None = None) -> None:
    with conn() as c:
        payload = state_payload(c, game_id)
    msg = {"type": "countdown", "countdown": payload}
    if extra:
        msg.update(extra)
    await hub.broadcast(game_id, msg)


def countdown_tick() -> List[Tuple[str, dict]]:
    """由主循环每 2 秒调用；返回 (game_id, 广播消息)。"""
    events: List[Tuple[str, dict]] = []
    with conn() as c:
        gids = [r["game_id"] for r in c.execute(
            "SELECT DISTINCT game_id FROM countdowns WHERE status=?", (RUNNING,)
        ).fetchall()]
        for gid in gids:
            changed = False
            texts = []
            at = C.now()
            st = get_settings(c, gid)
            rows = list_rows(c, gid)
            expired = [r for r in rows if r["status"] == RUNNING and r["ends_at"] and r["ends_at"] <= at]
            for r in expired:
                c.execute("UPDATE countdowns SET status=?,remaining=0 WHERE id=?", (DONE, r["id"]))
                changed = True
                texts.append(f"{r['label']} 结束")
                if st["countdown_mode"] == SEQUENTIAL:
                    nxt = next((x for x in rows if x["seq"] > r["seq"] and x["status"] == IDLE), None)
                    if nxt:
                        _start_one(c, nxt, at)
                        texts.append(f"自动启动：{nxt['label']}")
            if changed:
                payload = state_payload(c, gid)
                events.append((gid, {
                    "type": "countdown", "countdown": payload,
                    "text": " · ".join(texts) + (" · 全部倒计时结束 🎉" if payload["all_done"] else ""),
                    "auto_advanced": any("自动启动" in t for t in texts),
                }))
    return events
