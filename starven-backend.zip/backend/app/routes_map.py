"""v2 地图定位：全程轨迹、双定位视图数据、一键公开全员定位、定位自检、导出。

坐标口径：手机上报的 GPS/BDS 为 WGS-84。地图瓦片源若为高德/腾讯系（GCJ-02），
前端会用 coords.js 的 wgs84ToGcj02 做偏移校正；OSM / 天地图直接用 WGS-84。
"""
from __future__ import annotations

import io
import json
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response
from pydantic import BaseModel, Field

from . import config as C
from .auth import current_user, require_admin
from .countdown import get_settings, update_settings
from .db import conn
from .game import get_game, get_player, radar_points
from .ws import hub

router = APIRouter(prefix="/api/games", tags=["地图与轨迹"])
admin_router = APIRouter(prefix="/api/admin/games", tags=["地图管理"])

# 不需要 key 即可用的瓦片源；天地图需填 tk
TILE_PRESETS = {
    "osm": {
        "name": "OpenStreetMap（WGS-84，全球通用）",
        "url": "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
        "crs": "WGS84", "maxZoom": 19, "subdomains": [],
        "attribution": "© OpenStreetMap contributors",
    },
    "gaode": {
        "name": "高德矢量瓦片（GCJ-02，国内推荐）",
        "url": "https://webrd0{s}.is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=8&x={x}&y={y}&z={z}",
        "crs": "GCJ02", "maxZoom": 18, "subdomains": ["1", "2", "3", "4"],
        "attribution": "© 高德地图",
    },
    "tianditu": {
        "name": "天地图（需 tk，WGS-84）",
        "url": "https://t{s}.tianditu.gov.cn/DataServer?T=vec_w&x={x}&y={y}&l={z}&tk={tk}",
        "crs": "WGS84", "maxZoom": 18, "subdomains": ["0", "1", "2", "3", "4", "5", "6", "7"],
        "attribution": "© 天地图",
    },
    "none": {
        "name": "纯轨迹画布（无瓦片，完全离线）",
        "url": "", "crs": "WGS84", "maxZoom": 19, "subdomains": [],
        "attribution": "星湾工作室 · 相对坐标轨迹",
    },
}


class TrackPoint(BaseModel):
    lat: float = Field(..., ge=-90, le=90)
    lng: float = Field(..., ge=-180, le=180)
    accuracy: float | None = None
    seq: int = Field(..., ge=0)
    recorded_at: float | None = None
    phase: str | None = None


class TrackBatch(BaseModel):
    points: list[TrackPoint] = Field(..., max_length=200)


class RevealIn(BaseModel):
    enabled: bool


class TilesIn(BaseModel):
    tiles: str
    tk: str = ""


def _can_see_all(c, game_id: str, user: dict) -> bool:
    st = get_settings(c, game_id)
    if st["reveal_all"]:
        return True
    if user["is_admin"]:
        return True
    p = get_player(c, game_id, user["id"])
    return bool(p and p["role"] == C.ASSISTANT)


def tile_config(c, game_id: str) -> dict:
    st = get_settings(c, game_id)
    key = st["map_tiles"] if st["map_tiles"] in TILE_PRESETS else "osm"
    cfg = dict(TILE_PRESETS[key])
    cfg["key"] = key
    return cfg


# ---------------------------------------------------------------- 成员
@router.post("/{game_id}/track")
def upload_track(game_id: str, body: TrackBatch, user: dict = Depends(current_user)):
    """批量上报轨迹点；seq 由客户端自增，服务端按 (game,user,seq) 去重，弱网重发不会重复。"""
    with conn() as c:
        g = get_game(c, game_id)
        if g["status"] == C.FINISHED:
            return {"ok": True, "accepted": 0, "detail": "比赛已结束，轨迹停止记录"}
        if not get_player(c, game_id, user["id"]) and not user["is_admin"]:
            raise HTTPException(status_code=403, detail="请先加入比赛")
        n = 0
        for p in body.points:
            cur = c.execute(
                "INSERT OR IGNORE INTO track_points(game_id,user_id,seq,lat,lng,accuracy,phase,recorded_at) "
                "VALUES(?,?,?,?,?,?,?,?)",
                (game_id, user["id"], p.seq, p.lat, p.lng, p.accuracy,
                 p.phase or g["status"], p.recorded_at or C.now()),
            )
            n += cur.rowcount
        total = c.execute(
            "SELECT COUNT(*) n FROM track_points WHERE game_id=? AND user_id=?",
            (game_id, user["id"]),
        ).fetchone()["n"]
        last = c.execute(
            "SELECT recorded_at FROM track_points WHERE game_id=? AND user_id=? ORDER BY id DESC LIMIT 1",
            (game_id, user["id"]),
        ).fetchone()
    return {"ok": True, "accepted": n, "total": total,
            "last_at": last["recorded_at"] if last else None, "server_now": C.now()}


@router.get("/{game_id}/tracks")
def get_tracks(
    game_id: str,
    user_id: Optional[int] = Query(default=None),
    since: float = 0,
    limit: int = Query(default=3000, ge=1, le=20000),
    user: dict = Depends(current_user),
):
    with conn() as c:
        get_game(c, game_id)
        see_all = _can_see_all(c, game_id, user)
        if user_id is not None and user_id != user["id"] and not see_all:
            raise HTTPException(status_code=403, detail="当前未公开全员定位，只能查看自己的轨迹")
        params: list = [game_id, max(0.0, since)]
        sql = ("SELECT id,user_id,seq,lat,lng,accuracy,phase,recorded_at FROM track_points "
               "WHERE game_id=? AND recorded_at>=?")
        if not see_all:
            sql += " AND user_id=?"
            params.append(user["id"])
        elif user_id is not None:
            sql += " AND user_id=?"
            params.append(user_id)
        rows = c.execute(sql + " ORDER BY recorded_at,id LIMIT ?", params + [limit]).fetchall()
        names = {r["id"]: r["display_name"] for r in c.execute(
            "SELECT id,display_name FROM users").fetchall()}
        items = [dict(r) | {"name": names.get(r["user_id"], "?")} for r in rows]
        return {
            "items": items, "count": len(items), "see_all": see_all,
            "reveal_all": bool(get_settings(c, game_id)["reveal_all"]),
            "server_now": C.now(),
        }


@router.get("/{game_id}/map")
def map_state(game_id: str, user: dict = Depends(current_user)):
    """地图视图一次拿齐：中心、瓦片配置、权限、实时点、轨迹、公开开关。"""
    with conn() as c:
        g = get_game(c, game_id)
        st = get_settings(c, game_id)
        radar = radar_points(c, game_id, user, g)
        see_all = _can_see_all(c, game_id, user)
        params: list = [game_id]
        sql = ("SELECT t.user_id,t.seq,t.lat,t.lng,t.accuracy,t.recorded_at,u.display_name "
               "FROM track_points t JOIN users u ON u.id=t.user_id WHERE t.game_id=?")
        if not see_all:
            sql += " AND t.user_id=?"
            params.append(user["id"])
        rows = c.execute(sql + " ORDER BY t.id DESC LIMIT 4000", params).fetchall()
        tracks = [dict(r) for r in rows][::-1]
        return {
            "center": {"lat": g["center_lat"], "lng": g["center_lng"], "radius_m": g["radius_m"]},
            "tiles": tile_config(c, game_id),
            "tile_presets": TILE_PRESETS,
            "reveal_all": bool(st["reveal_all"]),
            "see_all": see_all,
            "is_admin": bool(user["is_admin"]),
            "points": radar["points"],
            "role": radar["role"],
            "tracks": tracks,
            "server_now": C.now(),
        }


@router.get("/{game_id}/geo-status")
def geo_status(game_id: str, user: dict = Depends(current_user)):
    """定位自检：一次性告诉前端「到底能不能用」，避开现场抓瞎。"""
    with conn() as c:
        get_game(c, game_id)
        live = c.execute(
            "SELECT * FROM live_positions WHERE game_id=? AND user_id=? AND kind='real'",
            (game_id, user["id"]),
        ).fetchone()
        cnt = c.execute(
            "SELECT COUNT(*) n FROM track_points WHERE game_id=? AND user_id=?",
            (game_id, user["id"]),
        ).fetchone()["n"]
        last = c.execute(
            "SELECT recorded_at,lat,lng,accuracy FROM track_points "
            "WHERE game_id=? AND user_id=? ORDER BY id DESC LIMIT 1",
            (game_id, user["id"]),
        ).fetchone()
        return {
            "server_now": C.now(),
            "has_live_fix": bool(live),
            "live_fix": dict(live) if live else None,
            "track_points": cnt,
            "last_track": dict(last) if last else None,
            "ws_clients": hub.presence(game_id),
            "tiles": tile_config(c, game_id),
            "hints": [
                "浏览器定位需要 HTTPS 安全上下文（或 localhost）",
                "系统需给浏览器「使用期间」位置权限",
                "GPS/BDS 在户外开阔处最准，室内会飘",
                "高德/腾讯瓦片是 GCJ-02，前端会自动把 WGS-84 坐标做偏移校正",
            ],
        }


# ---------------------------------------------------------------- 管理
@admin_router.post("/{game_id}/reveal")
async def set_reveal(game_id: str, body: RevealIn, user: dict = Depends(current_user)):
    require_admin(user)
    with conn() as c:
        get_game(c, game_id)
        update_settings(c, game_id, reveal_all=1 if body.enabled else 0)
    await hub.broadcast(game_id, {
        "type": "reveal", "enabled": body.enabled,
        "text": "📍 已公开全员定位与轨迹" if body.enabled else "🔒 已关闭全员定位公开",
    })
    return {"ok": True, "enabled": body.enabled}


@admin_router.patch("/{game_id}/map-tiles")
async def set_tiles(game_id: str, body: TilesIn, user: dict = Depends(current_user)):
    require_admin(user)
    if body.tiles not in TILE_PRESETS:
        raise HTTPException(status_code=400, detail="未知瓦片源")
    if body.tiles == "tianditu" and not body.tk.strip():
        raise HTTPException(status_code=400, detail="天地图需要填写 tk")
    value = body.tiles if not body.tk.strip() else f"{body.tiles}:{body.tk.strip()}"
    # tk 单独存在前端 localStorage，这里只落主源名（避免把 key 写进数据库）
    with conn() as c:
        get_game(c, game_id)
        update_settings(c, game_id, map_tiles=body.tiles)
    await hub.broadcast(game_id, {"type": "tiles", "tiles": body.tiles,
                                  "text": f"地图源已切换为 {TILE_PRESETS[body.tiles]['name']}"})
    return {"ok": True, "tiles": body.tiles, "crs": TILE_PRESETS[body.tiles]["crs"],
            "tk": body.tk.strip()}


@admin_router.get("/{game_id}/tracks/export")
def export_tracks(game_id: str, format: str = "geojson", user: dict = Depends(current_user)):
    require_admin(user)
    with conn() as c:
        get_game(c, game_id)
        rows = c.execute(
            "SELECT t.*,u.display_name,u.username FROM track_points t JOIN users u ON u.id=t.user_id "
            "WHERE t.game_id=? ORDER BY t.user_id,t.recorded_at,t.id", (game_id,)
        ).fetchall()
    if format == "csv":
        buf = io.StringIO()
        buf.write("user_id,username,display_name,seq,lat,lng,accuracy,phase,recorded_at\n")
        for r in rows:
            buf.write(f"{r['user_id']},{r['username']},{r['display_name']},{r['seq']},"
                      f"{r['lat']},{r['lng']},{r['accuracy'] or ''},{r['phase'] or ''},{r['recorded_at']}\n")
        return Response(
            content=buf.getvalue().encode("utf-8-sig"), media_type="text/csv",
            headers={"Content-Disposition": f'attachment; filename="starven-tracks-{game_id}.csv"'},
        )
    # GeoJSON：按人一条 LineString
    grouped = {}
    for r in rows:
        grouped.setdefault(r["user_id"], {"name": r["display_name"], "pts": []})["pts"].append(
            [r["lng"], r["lat"]]
        )
    fc = {"type": "FeatureCollection", "features": [
        {"type": "Feature",
         "properties": {"user_id": str(uid), "name": v["name"], "points": len(v["pts"])},
         "geometry": {"type": "LineString", "coordinates": v["pts"]}}
        for uid, v in grouped.items()
    ]}
    return Response(
        content=json.dumps(fc, ensure_ascii=False).encode("utf-8"),
        media_type="application/geo+json",
        headers={"Content-Disposition": f'attachment; filename="starven-tracks-{game_id}.geojson"'},
    )
