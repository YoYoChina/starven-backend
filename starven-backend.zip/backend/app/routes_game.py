"""成员端：加入比赛、实时状态、定位上报、扫一扫、雷达、积分榜、玩家身份码。"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from . import config as C
from .auth import current_user
from .db import conn
from .game import (
    apply_score, get_game, get_player, leaderboard, log_event, maybe_finish,
    nearby_hiders, phase_info, radar_points, state_for,
)
from .utils import (
    make_player_code, qr_svg, random_decoy, verify_ball_code, verify_player_code,
)
from .ws import hub

router = APIRouter(prefix="/api/games", tags=["比赛"])


class JoinIn(BaseModel):
    join_code: str


class PositionIn(BaseModel):
    lat: float = Field(..., ge=-90, le=90)
    lng: float = Field(..., ge=-180, le=180)
    accuracy: float | None = None


class ScanIn(BaseModel):
    code: str


def _latest_game_id(c, user: dict):
    if user["is_admin"]:
        row = c.execute("SELECT id FROM games ORDER BY created_at DESC LIMIT 1").fetchone()
    else:
        row = c.execute(
            "SELECT g.id FROM games g JOIN game_players gp ON gp.game_id=g.id "
            "WHERE gp.user_id=? ORDER BY g.created_at DESC LIMIT 1", (user["id"],)
        ).fetchone()
    return row["id"] if row else None


@router.post("/join")
def join_game(body: JoinIn, user: dict = Depends(current_user)):
    code = body.join_code.strip().upper()
    with conn() as c:
        g = c.execute("SELECT * FROM games WHERE join_code=?", (code,)).fetchone()
        if not g:
            raise HTTPException(status_code=404, detail="比赛码不存在，请向管理员确认")
        if g["status"] == C.FINISHED:
            raise HTTPException(status_code=400, detail="比赛已结束")
        if user["is_admin"]:
            return {"ok": True, "game_id": g["id"], "name": g["name"], "detail": "管理员无需加入名单"}
        if get_player(c, g["id"], user["id"]):
            return {"ok": True, "game_id": g["id"], "name": g["name"], "detail": "你已在名单中"}
        if g["status"] not in (C.DRAFT, C.HIDING):
            raise HTTPException(status_code=400, detail="比赛已进入抓捕阶段，无法中途加入")
        c.execute(
            "INSERT INTO game_players(game_id,user_id,role,alive,score,joined_at) VALUES(?,?,?,1,0,?)",
            (g["id"], user["id"], C.PENDING, C.now()),
        )
    return {"ok": True, "game_id": g["id"], "name": g["name"], "detail": "加入成功，等待现场抽签"}


@router.get("/current")
def current(user: dict = Depends(current_user)):
    with conn() as c:
        gid = _latest_game_id(c, user)
        if not gid:
            return {"has_game": False, "detail": "还没有比赛，输入比赛码加入吧"}
        return {"has_game": True, **state_for(c, gid, user)}


@router.get("/{game_id}/state")
def game_state(game_id: str, user: dict = Depends(current_user)):
    with conn() as c:
        get_game(c, game_id)
        if not user["is_admin"] and not get_player(c, game_id, user["id"]):
            raise HTTPException(status_code=403, detail="你还没有加入这场比赛")
        return state_for(c, game_id, user)


@router.get("/{game_id}/leaderboard")
def game_leaderboard(game_id: str, user: dict = Depends(current_user)):
    with conn() as c:
        get_game(c, game_id)
        return {"items": leaderboard(c, game_id)}


@router.get("/{game_id}/score-events")
def score_events(game_id: str, user: dict = Depends(current_user)):
    with conn() as c:
        get_game(c, game_id)
        rows = c.execute(
            "SELECT s.*, u.display_name FROM score_events s JOIN users u ON u.id=s.user_id "
            "WHERE s.game_id=? ORDER BY s.id DESC LIMIT 100", (game_id,)
        ).fetchall()
    return {"items": [dict(r) for r in rows]}


@router.get("/{game_id}/radar")
def radar(game_id: str, user: dict = Depends(current_user)):
    with conn() as c:
        g = get_game(c, game_id)
        return radar_points(c, game_id, user, g)


@router.get("/{game_id}/my-qr")
def my_qr(game_id: str, user: dict = Depends(current_user)):
    with conn() as c:
        get_game(c, game_id)
        if not get_player(c, game_id, user["id"]) and not user["is_admin"]:
            raise HTTPException(status_code=403, detail="请先加入比赛")
    code = make_player_code(user["id"])
    return {"code": code, "svg": qr_svg(code), "hint": "抓捕阶段被抓捕者扫到即判定被抓"}


@router.post("/{game_id}/position")
async def report_position(game_id: str, body: PositionIn, user: dict = Depends(current_user)):
    """全程上报 GPS/BDS 融合定位；仅管理员与协助者可见真实点，不影响玩法判定。"""
    with conn() as c:
        g = get_game(c, game_id)
        if g["status"] == C.FINISHED:
            raise HTTPException(status_code=400, detail="比赛已结束")
        if not get_player(c, game_id, user["id"]) and not user["is_admin"]:
            raise HTTPException(status_code=403, detail="请先加入比赛")
        c.execute(
            "INSERT INTO live_positions(game_id,user_id,kind,lat,lng,accuracy,updated_at) "
            "VALUES(?,?,'real',?,?,?,?) ON CONFLICT(game_id,user_id,kind) DO UPDATE SET "
            "lat=excluded.lat,lng=excluded.lng,accuracy=excluded.accuracy,updated_at=excluded.updated_at",
            (game_id, user["id"], body.lat, body.lng, body.accuracy, C.now()),
        )
    await hub.broadcast_roles(
        game_id, {C.ASSISTANT},
        {"type": "position", "uid": user["id"], "name": user["display_name"],
         "lat": body.lat, "lng": body.lng, "at": C.now()},
    )
    return {"ok": True, "at": C.now()}


@router.post("/{game_id}/scan")
async def scan(game_id: str, body: ScanIn, user: dict = Depends(current_user)):
    """公告核心玩法：扫道具球 / 扫玩家身份码。"""
    code = body.code.strip().upper()
    with conn() as c:
        g = get_game(c, game_id)
        if g["status"] not in (C.HIDING, C.CHASING):
            raise HTTPException(status_code=400, detail="比赛未在进行中，暂不能扫球")
        p = get_player(c, game_id, user["id"])
        if not p and not user["is_admin"]:
            raise HTTPException(status_code=403, detail="你还没有加入这场比赛")
        role = p["role"] if p else C.ASSISTANT
        uid = user["id"]

        # ---------- 玩家身份码：抓捕者确认抓获 ----------
        target_id = verify_player_code(code)
        if target_id is not None:
            if role != C.CATCHER:
                raise HTTPException(status_code=400, detail="只有抓捕者可以扫玩家身份码")
            if g["status"] != C.CHASING:
                raise HTTPException(status_code=400, detail="抓捕阶段才能确认抓获")
            t = get_player(c, game_id, target_id)
            if not t or t["role"] != C.HIDER or not t["alive"]:
                raise HTTPException(status_code=400, detail="该玩家不是存活的躲藏者")
            name = c.execute("SELECT display_name FROM users WHERE id=?", (target_id,)).fetchone()["display_name"]
            c.execute(
                "UPDATE game_players SET alive=0, caught_at=? WHERE game_id=? AND user_id=?",
                (C.now(), game_id, target_id),
            )
            score = apply_score(c, game_id, uid, 10.0, f"抓获 {name}")
            log_event(c, game_id, uid, code, "catch", f"抓获 {name}")
            winner = maybe_finish(c, game_id)
            result = {
                "ok": True, "kind": "catch", "score": score, "delta": 10.0,
                "title": f"抓获 {name} ！", "detail": "抓捕者 +10 积分",
                "target_id": target_id, "winner": winner,
            }
            await hub.broadcast(
                game_id,
                {"type": "caught", "text": f"{user['display_name']} 抓获了 {name}（+10 分）",
                 "target_id": target_id, "catcher": uid},
            )
            if winner:
                await hub.broadcast(game_id, {"type": "game_over", "winner": winner,
                                              "text": "抓捕者获胜 🎯"})
            await hub.broadcast(game_id, {"type": "refresh"})
            return result

        # ---------- 道具球码 ----------
        if not verify_ball_code(code):
            raise HTTPException(status_code=400, detail="无法识别的二维码：请扫道具球码或玩家身份码")
        if role not in (C.CATCHER, C.HIDER):
            return {"ok": True, "kind": "neutral", "title": "协助者 / 管理员",
                    "detail": "本角色不参与计分，球码保持可用", "score": 0}

        ball = c.execute("SELECT * FROM balls WHERE code=? AND game_id=?", (code, game_id)).fetchone()
        if not ball:
            raise HTTPException(status_code=400, detail="这不是本场比赛的道具小球")
        if ball["used_by"]:
            raise HTTPException(status_code=400, detail="这颗小球已经被扫描过了")

        if role == C.HIDER and not p["alive"]:
            raise HTTPException(status_code=400, detail="你已被抓获，无法继续使用道具")

        if role == C.HIDER:
            lat, lng = random_decoy(g["center_lat"], g["center_lng"], g["radius_m"])
            c.execute(
                "INSERT INTO decoys(game_id,user_id,lat,lng,code,created_at) VALUES(?,?,?,?,?,?)",
                (game_id, uid, lat, lng, code, C.now()),
            )
            score = apply_score(c, game_id, uid, 0.5, f"扫球 {ball['label']}：发送随机错误定位")
            log_event(c, game_id, uid, code, "hider_decoy", ball["label"])
            result = {
                "ok": True, "kind": "hider_decoy", "score": score, "delta": 0.5,
                "title": "随机错误定位已发送", "detail": "抓捕者收到一条可疑定位，你的真实位置不会暴露",
                "ball": ball["label"],
            }
            await hub.broadcast_roles(
                game_id, {C.CATCHER},
                {"type": "decoy", "lat": lat, "lng": lng, "ball": ball["label"],
                 "text": "收到一条可疑定位信号（随机错误定位）", "at": C.now()},
            )
        else:
            mine = c.execute(
                "SELECT * FROM live_positions WHERE game_id=? AND user_id=? AND kind='real'",
                (game_id, uid),
            ).fetchone()
            if not mine:
                raise HTTPException(status_code=400, detail="尚未获取到你的定位，请开启定位权限后重试")
            found = nearby_hiders(c, game_id, mine["lat"], mine["lng"], C.RADAR_RANGE_M)
            score = apply_score(c, game_id, uid, 0.5, f"扫球 {ball['label']}：30 米探测")
            log_event(c, game_id, uid, code, "catcher_radar",
                      f"30米内 {len(found)} 名躲藏者")
            result = {
                "ok": True, "kind": "catcher_radar", "score": score, "delta": 0.5,
                "found": bool(found), "count": len(found), "sectors": found,
                "title": f"30 米内{'发现 ' + str(len(found)) + ' 名躲藏者' if found else '没有躲藏者'}",
                "detail": "、".join(f"{x['sector']} 约 {x['dist_m']} 米" for x in found) or "附近暂时安全",
                "ball": ball["label"],
            }
            await hub.send_user(uid, {"type": "radar_result", **result})

        c.execute("UPDATE balls SET used_by=?, used_at=? WHERE code=?", (uid, C.now(), code))
        await hub.broadcast(game_id, {"type": "refresh"})
        return result
