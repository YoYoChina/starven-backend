"""通用工具：短码签名、距离换算、方位、随机错误定位。"""
from __future__ import annotations

import hashlib
import hmac
import math
import secrets
from typing import Optional, Tuple

from .config import SECRET_KEY


def _sig(text: str, length: int = 4) -> str:
    return hmac.new(SECRET_KEY.encode(), text.encode(), hashlib.sha256).hexdigest()[:length].upper()


def make_ball_code() -> str:
    """道具小球码：B-XXXXXX-YYYY，附带防伪造签名，便于手动输入。"""
    rnd = secrets.token_hex(3).upper()
    return f"B-{rnd}-{_sig('ball:' + rnd, 4)}"


def verify_ball_code(code: str) -> bool:
    try:
        _, rnd, sig = code.strip().upper().split("-")
        return len(rnd) == 6 and hmac.compare_digest(sig, _sig("ball:" + rnd, 4))
    except Exception:
        return False


def make_player_code(user_id: int) -> str:
    """玩家身份码：抓捕者扫到它即完成一次抓获判定。"""
    return f"P-{user_id}-{_sig('player:' + str(user_id), 6)}"


def verify_player_code(code: str) -> Optional[int]:
    try:
        _, uid, sig = code.strip().upper().split("-")
        uid_int = int(uid)
        if hmac.compare_digest(sig, _sig("player:" + uid, 6)):
            return uid_int
    except Exception:
        pass
    return None


def make_join_code() -> str:
    return secrets.token_hex(3).upper()


def make_game_id() -> str:
    return secrets.token_hex(5)


def make_invite_code() -> str:
    return "SV-" + secrets.token_hex(3).upper()


def haversine_m(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    """球面距离，单位米。"""
    r = 6371008.8
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = p2 - p1
    dl = math.radians(lng2 - lng1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(min(1.0, math.sqrt(a)))


def bearing_cn(lat1: float, lng1: float, lat2: float, lng2: float) -> str:
    """8 方位，只给模糊方位，不暴露精确坐标。"""
    dy = (lat2 - lat1) * 111320
    dx = (lng2 - lng1) * 111320 * math.cos(math.radians(lat1))
    ang = (math.degrees(math.atan2(dx, dy)) + 360) % 360
    names = ["正北", "东北", "正东", "东南", "正南", "西南", "正西", "西北"]
    return names[int((ang + 22.5) // 45) % 8]


def random_decoy(lat: float, lng: float, radius_m: float) -> Tuple[float, float]:
    """在场地范围内生成一个随机错误定位（高斯偏向远处，更像真实跑动）。"""
    import random
    r = radius_m * min(0.98, max(0.15, random.gauss(0.68, 0.22)))
    theta = random.uniform(0, 2 * math.pi)
    dlat = r * math.cos(theta) / 111320
    dlng = r * math.sin(theta) / (111320 * max(0.01, math.cos(math.radians(lat))))
    return round(lat + dlat, 7), round(lng + dlng, 7)


def qr_svg(text: str, scale: int = 5) -> str:
    """生成内嵌 SVG 二维码，前端直接插入 DOM，不依赖任何 CDN。"""
    import io
    import segno
    qr = segno.make(text, error="m")
    buf = io.BytesIO()
    qr.save(buf, kind="svg", scale=scale, border=2, xmldecl=False, nl=False)
    return buf.getvalue().decode("utf-8")
