"""登录 / 注册 / 资料 / 邀请码：一个正常 APP 该有的账号闭环。"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from . import config as C
from .auth import (
    check_password, check_username, current_user, hash_password, make_token,
    new_salt, require_admin, verify_password,
)
from .db import conn
from .utils import make_invite_code

router = APIRouter(prefix="/api/auth", tags=["账号"])


class RegisterIn(BaseModel):
    username: str
    password: str
    display_name: str = Field(..., min_length=1, max_length=20)
    invite_code: str


class LoginIn(BaseModel):
    username: str
    password: str


class PasswordIn(BaseModel):
    old_password: str
    new_password: str


class InviteIn(BaseModel):
    count: int = Field(default=10, ge=1, le=100)
    note: str = ""


def public_user(row: dict) -> dict:
    return {
        "id": row["id"], "username": row["username"],
        "display_name": row["display_name"], "is_admin": bool(row["is_admin"]),
        "created_at": row["created_at"],
    }


@router.post("/register")
def register(body: RegisterIn):
    username = check_username(body.username)
    password = check_password(body.password)
    display = body.display_name.strip()
    code = body.invite_code.strip().upper()
    with conn() as c:
        inv = c.execute("SELECT * FROM invites WHERE code=?", (code,)).fetchone()
        if not inv:
            raise HTTPException(status_code=400, detail="邀请码无效")
        if inv["used_by"]:
            raise HTTPException(status_code=400, detail="该邀请码已被使用，请找管理员领取新码")
        if inv["expires_at"] and inv["expires_at"] < C.now():
            raise HTTPException(status_code=400, detail="邀请码已过期")
        if c.execute("SELECT 1 FROM users WHERE username=?", (username,)).fetchone():
            raise HTTPException(status_code=400, detail="用户名已被占用")
        salt = new_salt()
        cur = c.execute(
            "INSERT INTO users(username,display_name,password_hash,salt,is_admin,created_at) "
            "VALUES(?,?,?,?,0,?)",
            (username, display, hash_password(password, salt), salt, C.now()),
        )
        uid = cur.lastrowid
        c.execute("UPDATE invites SET used_by=?, used_at=? WHERE code=?", (uid, C.now(), code))
        row = c.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    return {"token": make_token(dict(row)), "user": public_user(dict(row))}


@router.post("/login")
def login(body: LoginIn):
    with conn() as c:
        row = c.execute("SELECT * FROM users WHERE username=?", (body.username.strip(),)).fetchone()
        if not row or not verify_password(body.password, row["salt"], row["password_hash"]):
            raise HTTPException(status_code=401, detail="用户名或密码错误")
        c.execute("UPDATE users SET last_login=? WHERE id=?", (C.now(), row["id"]))
        u = dict(row)
    return {"token": make_token(u), "user": public_user(u)}


@router.get("/me")
def me(user: dict = Depends(current_user)):
    with conn() as c:
        g = c.execute(
            "SELECT g.id, g.name, g.status FROM games g JOIN game_players gp ON gp.game_id=g.id "
            "WHERE gp.user_id=? ORDER BY g.created_at DESC LIMIT 1", (user["id"],)
        ).fetchone()
    return {"user": public_user(user), "current_game": dict(g) if g else None}


@router.post("/password")
def change_password(body: PasswordIn, user: dict = Depends(current_user)):
    check_password(body.new_password)
    if not verify_password(body.old_password, user["salt"], user["password_hash"]):
        raise HTTPException(status_code=400, detail="原密码不正确")
    salt = new_salt()
    with conn() as c:
        c.execute(
            "UPDATE users SET salt=?, password_hash=? WHERE id=?",
            (salt, hash_password(body.new_password, salt), user["id"]),
        )
    return {"ok": True, "detail": "密码已修改，请重新登录"}


@router.post("/logout")
def logout(user: dict = Depends(current_user)):
    # JWT 无状态：客户端清除本地令牌即可，服务端不保留会话。
    return {"ok": True}


@router.get("/invites")
def list_invites(user: dict = Depends(current_user)):
    require_admin(user)
    with conn() as c:
        rows = c.execute("SELECT * FROM invites ORDER BY created_at DESC").fetchall()
    return {"items": [dict(r) for r in rows]}


@router.post("/invites")
def create_invites(body: InviteIn, user: dict = Depends(current_user)):
    require_admin(user)
    created = []
    with conn() as c:
        for _ in range(body.count):
            code = make_invite_code()
            c.execute(
                "INSERT INTO invites(code,note,created_by,created_at) VALUES(?,?,?,?)",
                (code, body.note.strip() or "现场成员邀请码", user["id"], C.now()),
            )
            created.append(code)
    return {"ok": True, "codes": created, "count": len(created)}
