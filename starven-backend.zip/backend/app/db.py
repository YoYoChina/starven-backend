"""SQLite 数据层：WAL 模式，每次请求独立连接，适合 14~40 人的单场活动。"""
from __future__ import annotations

import sqlite3
import threading
from contextlib import contextmanager

from . import config as C
from .config import DB_PATH

_init_lock = threading.Lock()
_initialized = False

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  display_name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  salt TEXT NOT NULL,
  is_admin INTEGER NOT NULL DEFAULT 0,
  created_at REAL NOT NULL,
  last_login REAL
);

CREATE TABLE IF NOT EXISTS invites (
  code TEXT PRIMARY KEY,
  note TEXT NOT NULL DEFAULT '',
  created_by INTEGER,
  used_by INTEGER,
  used_at REAL,
  created_at REAL NOT NULL,
  expires_at REAL
);

CREATE TABLE IF NOT EXISTS games (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  join_code TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'draft',
  hide_minutes REAL NOT NULL DEFAULT 30,
  chase_minutes REAL NOT NULL DEFAULT 30,
  center_lat REAL NOT NULL DEFAULT 0,
  center_lng REAL NOT NULL DEFAULT 0,
  radius_m REAL NOT NULL DEFAULT 150,
  phase_started_at REAL,
  winner TEXT,
  created_by INTEGER,
  created_at REAL NOT NULL,
  finished_at REAL
);

CREATE TABLE IF NOT EXISTS game_players (
  game_id TEXT NOT NULL,
  user_id INTEGER NOT NULL,
  role TEXT NOT NULL DEFAULT 'pending',
  alive INTEGER NOT NULL DEFAULT 1,
  score REAL NOT NULL DEFAULT 0,
  caught_at REAL,
  joined_at REAL NOT NULL,
  PRIMARY KEY (game_id, user_id)
);

CREATE TABLE IF NOT EXISTS balls (
  code TEXT PRIMARY KEY,
  game_id TEXT NOT NULL,
  label TEXT NOT NULL,
  used_by INTEGER,
  used_at REAL,
  created_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_balls_game ON balls(game_id);

CREATE TABLE IF NOT EXISTS decoys (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  game_id TEXT NOT NULL,
  user_id INTEGER NOT NULL,
  lat REAL NOT NULL,
  lng REAL NOT NULL,
  code TEXT NOT NULL,
  created_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_decoys_game ON decoys(game_id, created_at);

CREATE TABLE IF NOT EXISTS live_positions (
  game_id TEXT NOT NULL,
  user_id INTEGER NOT NULL,
  kind TEXT NOT NULL DEFAULT 'real',
  lat REAL NOT NULL,
  lng REAL NOT NULL,
  accuracy REAL,
  updated_at REAL NOT NULL,
  PRIMARY KEY (game_id, user_id, kind)
);

CREATE TABLE IF NOT EXISTS score_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  game_id TEXT NOT NULL,
  user_id INTEGER NOT NULL,
  delta REAL NOT NULL,
  reason TEXT NOT NULL,
  created_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_score_game ON score_events(game_id, id);

CREATE TABLE IF NOT EXISTS tick_marks (
  game_id TEXT NOT NULL,
  phase TEXT NOT NULL,
  mark INTEGER NOT NULL,
  created_at REAL NOT NULL,
  PRIMARY KEY (game_id, phase, mark)
);

CREATE TABLE IF NOT EXISTS scan_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  game_id TEXT NOT NULL,
  user_id INTEGER NOT NULL,
  code TEXT NOT NULL,
  kind TEXT NOT NULL,
  detail TEXT NOT NULL DEFAULT '',
  created_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_scan_game ON scan_events(game_id, id);

-- v2：自定义倒计时（多段、顺序/同时两种显示与执行模式）
CREATE TABLE IF NOT EXISTS countdowns (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  game_id TEXT NOT NULL,
  seq INTEGER NOT NULL,
  label TEXT NOT NULL,
  duration REAL NOT NULL,
  started_at REAL,
  ends_at REAL,
  remaining REAL,
  status TEXT NOT NULL DEFAULT 'idle',  -- idle / running / paused / done
  created_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_cd_game_seq ON countdowns(game_id, seq);

-- v2：比赛级设置
CREATE TABLE IF NOT EXISTS game_settings (
  game_id TEXT PRIMARY KEY,
  countdown_mode TEXT NOT NULL DEFAULT 'sequential',  -- sequential | parallel
  reveal_all INTEGER NOT NULL DEFAULT 0,
  map_tiles TEXT NOT NULL DEFAULT 'osm',
  updated_at REAL NOT NULL
);

-- v2：全程轨迹点（批量上报，按人 + 时间序列）
CREATE TABLE IF NOT EXISTS track_points (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  game_id TEXT NOT NULL,
  user_id INTEGER NOT NULL,
  seq INTEGER NOT NULL DEFAULT 0,
  lat REAL NOT NULL,
  lng REAL NOT NULL,
  accuracy REAL,
  phase TEXT,
  recorded_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_track_game_user ON track_points(game_id, user_id, id);
CREATE INDEX IF NOT EXISTS idx_track_game_time ON track_points(game_id, recorded_at);
CREATE UNIQUE INDEX IF NOT EXISTS uq_track_seq ON track_points(game_id, user_id, seq);
"""


def get_conn() -> sqlite3.Connection:
    c = sqlite3.connect(str(DB_PATH), timeout=15, check_same_thread=False)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA foreign_keys=ON")
    c.execute("PRAGMA busy_timeout=10000")
    return c


@contextmanager
def conn():
    c = get_conn()
    try:
        yield c
        c.commit()
    except Exception:
        c.rollback()
        raise
    finally:
        c.close()


def init_db() -> None:
    global _initialized
    with _init_lock:
        if _initialized:
            return
        with conn() as c:
            c.executescript(SCHEMA)
            # 旧库升级：补齐历史比赛的默认设置行
            c.execute(
                "INSERT OR IGNORE INTO game_settings(game_id,countdown_mode,reveal_all,map_tiles,updated_at) "
                "SELECT id,'sequential',0,'osm',? FROM games", (C.now(),)
            )
        _initialized = True
