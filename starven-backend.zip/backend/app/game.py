"""玩法引擎：严格对应公告规则，所有计分与判定集中在这里，便于核对。

规则映射：
- 比赛开启人数 >= 14，抓捕者 1 / 躲藏者 10 / 协助者 3，人数按比例类推
- 角色由现场抽签决定
- 扫球：躲藏者 -> 向抓捕者发送随机错误定位 +0.5；抓捕者 -> 查 30 米内有无躲藏者 +0.5
- 躲藏 30 分钟、抓捕 30 分钟；躲藏者每存活 5 分钟 +1；抓捕者每抓一人 +10
- 存活到最后则躲藏者获胜，无幸存者则抓捕者获胜
"""
from __future__ import annotations

import secrets
from typing import List, Optional, Tuple

from fastapi import HTTPException

from . import config as C
from .auth import hash_password, new_salt
from .db import conn
from .utils import (
    bearing_cn,
    haversine_m,
    make_ball_code,
    make_game_id,
    make_invite_code,
    make_join_code,
)


# ---------------------------------------------------------------- 初始化
def bootstrap() -> Optional[str]:
    """创建初始管理员与首个邀请码，返回自动生成的管理员密码。"""
    generated = None
    with conn() as c:
        if not c.execute("SELECT 1 FROM users WHERE username=?", (C.ADMIN_USERNAME,)).fetchone():
            pw = C.ADMIN_PASSWORD or secrets.token_urlsafe(12)
            salt = new_salt()
            c.execute(
                "INSERT INTO users(username,display_name,password_hash,salt,is_admin,created_at) "
                "VALUES(?,?,?,?,1,?)",
                (C.ADMIN_USERNAME, C.ADMIN_DISPLAY, hash_password(pw, salt), salt, C.now()),
            )
            if not C.ADMIN_PASSWORD:
                generated = pw
                f = C.DATA_DIR / "初始管理员密码.txt"
                f.write_text(
                    f"星湾躲猫猫 APP 初始管理员\n账号：{C.ADMIN_USERNAME}\n密码：{pw}\n"
                    "请登录后立即修改，并删除本文件。\n",
                    encoding="utf-8",
                )
                try:
                    f.chmod(0o600)
                except OSError:
                    pass
        if not c.execute("SELECT 1 FROM invites WHERE code=?", (C.INVITE_CODE,)).fetchone():
            c.execute(
                "INSERT INTO invites(code,note,created_by,created_at) VALUES(?,?,NULL,?)",
                (C.INVITE_CODE, "初始成员邀请码", C.now()),
            )
    return generated


# ---------------------------------------------------------------- 角色分配
def allocate_roles(n: int) -> dict:
    """1 : 10 : 3 的比例，人数以此比例类推。"""
    if n < 14:
        raise HTTPException(status_code=400, detail=f"比赛开启人数需 ≥14 人，当前 {n} 人")
    catchers = max(1, round(n * 1 / 14))
    hiders = max(1, round(n * 10 / 14))
    assistants = n - catchers - hiders
    if assistants < 1:
        assistants = 1
        hiders = n - catchers - assistants
    return {C.CATCHER: catchers, C.HIDER: hiders, C.ASSISTANT: assistants}


def draw_roles(c, game_id: str) -> dict:
    """现场抽签：随机打乱后按比例分配，返回各角色名单。"""
    import random
    rows = c.execute(
        "SELECT gp.user_id, u.username, u.display_name FROM game_players gp "
        "JOIN users u ON u.id=gp.user_id WHERE gp.game_id=? ORDER BY gp.joined_at",
        (game_id,),
    ).fetchall()
    if len(rows) < 14:
        raise HTTPException(status_code=400, detail=f"需 ≥14 人才能抽签，当前 {len(rows)} 人")
    counts = allocate_roles(len(rows))
    people = [dict(r) for r in rows]
    random.shuffle(people)
    idx = 0
    result = {}
    for role in (C.CATCHER, C.HIDER, C.ASSISTANT):
        picked = people[idx: idx + counts[role]]
        idx += counts[role]
        result[role] = picked
        for p in picked:
            c.execute(
                "UPDATE game_players SET role=? WHERE game_id=? AND user_id=?",
                (role, game_id, p["user_id"]),
            )
    return result


# ---------------------------------------------------------------- 查询辅助
def get_game(c, game_id: str) -> dict:
    row = c.execute("SELECT * FROM games WHERE id=?", (game_id,)).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="比赛不存在")
    return dict(row)


def get_player(c, game_id: str, user_id: int) -> Optional[dict]:
    row = c.execute(
        "SELECT * FROM game_players WHERE game_id=? AND user_id=?", (game_id, user_id)
    ).fetchone()
    return dict(row) if row else None


def require_member(c, game_id: str, user: dict) -> dict:
    if user["is_admin"]:
        return {"role": "admin", "is_admin": True, "user_id": user["id"]}
    p = get_player(c, game_id, user["id"])
    if not p:
        raise HTTPException(status_code=403, detail="你还没有加入这场比赛")
    return p


def phase_info(g: dict) -> dict:
    st = g["status"]
    if st in (C.DRAFT, C.FINISHED):
        return {"phase": st, "phase_cn": C.PHASE_CN[st], "elapsed": 0,
                "remaining": 0, "duration": 0, "winner": g["winner"]}
    dur = (g["hide_minutes"] if st == C.HIDING else g["chase_minutes"]) * 60
    start = g["phase_started_at"] or C.now()
    elapsed = max(0.0, C.now() - start)
    return {
        "phase": st,
        "phase_cn": C.PHASE_CN[st],
        "elapsed": round(elapsed, 1),
        "remaining": round(max(0.0, dur - elapsed), 1),
        "duration": dur,
        "phase_started_at": start,
        "winner": g["winner"],
    }


def leaderboard(c, game_id: str) -> list:
    rows = c.execute(
        "SELECT gp.user_id, gp.role, gp.alive, gp.score, gp.caught_at, u.display_name, u.username "
        "FROM game_players gp JOIN users u ON u.id=gp.user_id "
        "WHERE gp.game_id=? ORDER BY gp.score DESC, gp.alive DESC, gp.joined_at",
        (game_id,),
    ).fetchall()
    out = []
    for i, r in enumerate(rows, 1):
        d = dict(r)
        d["rank"] = i
        d["role_cn"] = C.ROLE_CN.get(d["role"], d["role"])
        out.append(d)
    return out


def state_for(c, game_id: str, user: dict) -> dict:
    g = get_game(c, game_id)
    p = get_player(c, game_id, user["id"])
    board = leaderboard(c, game_id)
    alive_hiders = sum(1 for x in board if x["role"] == C.HIDER and x["alive"])
    total = len(board)
    me = next((x for x in board if x["user_id"] == user["id"]), None)
    return {
        "game": {k: g[k] for k in (
            "id", "name", "join_code", "status", "hide_minutes", "chase_minutes",
            "center_lat", "center_lng", "radius_m", "winner", "created_at")},
        "clock": phase_info(g),
        "me": {
            "user_id": user["id"],
            "display_name": user["display_name"],
            "username": user["username"],
            "is_admin": bool(user["is_admin"]),
            "role": (p or {}).get("role", C.PENDING) if not user["is_admin"] else "admin",
            "role_cn": "管理员" if user["is_admin"] else C.ROLE_CN.get((p or {}).get("role", C.PENDING), "未加入"),
            "score": (me or {}).get("score", 0),
            "alive": bool((me or {}).get("alive", 0)),
            "joined": bool(p),
        },
        "counts": {"total": total, "alive_hiders": alive_hiders,
                   "catchers": sum(1 for x in board if x["role"] == C.CATCHER),
                   "assistants": sum(1 for x in board if x["role"] == C.ASSISTANT)},
        "leaderboard": board,
        "recent_events": [
            dict(r) for r in c.execute(
                "SELECT s.*, u.display_name FROM scan_events s JOIN users u ON u.id=s.user_id "
                "WHERE s.game_id=? ORDER BY s.id DESC LIMIT 20", (game_id,)
            ).fetchall()
        ],
    }


def radar_points(c, game_id: str, user: dict, g: dict) -> dict:
    """按角色脱敏：抓捕者只看得到可疑信号，管理员/协助者可看全场真实定位用于拍摄展示。"""
    p = get_player(c, game_id, user["id"])
    role = p["role"] if p else C.PENDING
    # 管理员一键「公开全员定位」后，所有客户端都能同时看到全场真实点
    revealed = c.execute(
        "SELECT reveal_all FROM game_settings WHERE game_id=?", (game_id,)
    ).fetchone()
    public_reveal = bool(revealed and revealed["reveal_all"])
    privileged = bool(user["is_admin"]) or role == C.ASSISTANT or public_reveal
    pts = []
    reveal_all = public_reveal
    if privileged:
        rows = c.execute(
            "SELECT lp.user_id, lp.lat, lp.lng, lp.accuracy, lp.updated_at, gp.role, gp.alive, u.display_name "
            "FROM live_positions lp JOIN game_players gp ON gp.game_id=lp.game_id AND gp.user_id=lp.user_id "
            "JOIN users u ON u.id=lp.user_id WHERE lp.game_id=? AND lp.kind='real'",
            (game_id,),
        ).fetchall()
        seen = set()
        for r in rows:
            seen.add(r["user_id"])
            pts.append({"kind": "real", "id": r["user_id"], "label": r["display_name"],
                        "lat": r["lat"], "lng": r["lng"], "at": r["updated_at"],
                        "role": r["role"], "alive": bool(r["alive"])})
        # 轨迹兜底：有人短暂断网没上报实时点时，用其最后一个轨迹点补齐，
        # 保证「公开全员定位」时每个人都能同时出现在地图上。
        last_tracks = c.execute(
            "SELECT t.user_id,t.lat,t.lng,t.recorded_at,gp.role,gp.alive,u.display_name "
            "FROM track_points t JOIN game_players gp ON gp.game_id=t.game_id AND gp.user_id=t.user_id "
            "JOIN users u ON u.id=t.user_id "
            "WHERE t.game_id=? AND t.id IN (SELECT MAX(id) FROM track_points WHERE game_id=? GROUP BY user_id)",
            (game_id, game_id),
        ).fetchall()
        for r in last_tracks:
            if r["user_id"] in seen:
                continue
            pts.append({"kind": "real", "id": r["user_id"], "label": r["display_name"],
                        "lat": r["lat"], "lng": r["lng"], "at": r["recorded_at"],
                        "role": r["role"], "alive": bool(r["alive"]), "from_track": True})
    else:
        mine = c.execute(
            "SELECT * FROM live_positions WHERE game_id=? AND user_id=? AND kind='real'",
            (game_id, user["id"]),
        ).fetchone()
        if mine:
            pts.append({"kind": "self", "id": user["id"], "label": "我",
                        "lat": mine["lat"], "lng": mine["lng"], "at": mine["updated_at"]})
    if privileged or role == C.CATCHER:
        decoys = c.execute(
            "SELECT * FROM decoys WHERE game_id=? ORDER BY id DESC LIMIT 30", (game_id,)
        ).fetchall()
        for r in decoys:
            pts.append({"kind": "decoy", "id": f"d{r['id']}", "label": "可疑信号",
                        "lat": r["lat"], "lng": r["lng"], "at": r["created_at"]})
    return {
        "center": {"lat": g["center_lat"], "lng": g["center_lng"], "radius_m": g["radius_m"]},
        "role": role, "privileged": privileged, "reveal_all": reveal_all, "points": pts,
    }


# ---------------------------------------------------------------- 计分 / 判定
def apply_score(c, game_id: str, user_id: int, delta: float, reason: str) -> float:
    c.execute(
        "UPDATE game_players SET score=ROUND(score+?,2) WHERE game_id=? AND user_id=?",
        (delta, game_id, user_id),
    )
    c.execute(
        "INSERT INTO score_events(game_id,user_id,delta,reason,created_at) VALUES(?,?,?,?,?)",
        (game_id, user_id, delta, reason, C.now()),
    )
    row = c.execute(
        "SELECT score FROM game_players WHERE game_id=? AND user_id=?", (game_id, user_id)
    ).fetchone()
    return row["score"] if row else 0.0


def log_event(c, game_id: str, user_id: int, code: str, kind: str, detail: str = "") -> None:
    c.execute(
        "INSERT INTO scan_events(game_id,user_id,code,kind,detail,created_at) VALUES(?,?,?,?,?,?)",
        (game_id, user_id, code, kind, detail, C.now()),
    )


def finish_game(c, game_id: str) -> str:
    alive = c.execute(
        "SELECT COUNT(*) n FROM game_players WHERE game_id=? AND role=? AND alive=1",
        (game_id, C.HIDER),
    ).fetchone()["n"]
    winner = "hiders" if alive > 0 else "catcher"
    c.execute(
        "UPDATE games SET status=?, winner=?, finished_at=? WHERE id=?",
        (C.FINISHED, winner, C.now(), game_id),
    )
    return winner


def maybe_finish(c, game_id: str) -> Optional[str]:
    """全部躲藏者被抓 -> 公告：若无幸存者，则抓捕者获胜。"""
    alive = c.execute(
        "SELECT COUNT(*) n FROM game_players WHERE game_id=? AND role=? AND alive=1",
        (game_id, C.HIDER),
    ).fetchone()["n"]
    if alive == 0:
        g = get_game(c, game_id)
        if g["status"] == C.CHASING:
            return finish_game(c, game_id)
    return None


def engine_tick() -> List[Tuple[str, dict]]:
    """由后台任务每 TICK_SECONDS 调用一次：发放 5 分钟积分、切换阶段、判定胜负。"""
    events: List[Tuple[str, dict]] = []
    with conn() as c:
        games = c.execute("SELECT * FROM games WHERE status IN (?,?)", (C.HIDING, C.CHASING)).fetchall()
        for g in games:
            gid, phase = g["id"], g["status"]
            dur = (g["hide_minutes"] if phase == C.HIDING else g["chase_minutes"]) * 60
            start = g["phase_started_at"] or C.now()
            elapsed = max(0.0, C.now() - start)
            marks = min(int(elapsed // 300), int(dur // 300))
            for m in range(1, marks + 1):
                exists = c.execute(
                    "SELECT 1 FROM tick_marks WHERE game_id=? AND phase=? AND mark=?", (gid, phase, m)
                ).fetchone()
                if exists:
                    continue
                c.execute(
                    "INSERT INTO tick_marks(game_id,phase,mark,created_at) VALUES(?,?,?,?)",
                    (gid, phase, m, C.now()),
                )
                hiders = c.execute(
                    "SELECT user_id FROM game_players WHERE game_id=? AND role=? AND alive=1",
                    (gid, C.HIDER),
                ).fetchall()
                for h in hiders:
                    apply_score(c, gid, h["user_id"], 1.0, f"{C.PHASE_CN[phase]}存活满 {m*5} 分钟")
                events.append((gid, {"type": "score", "reason": f"存活满 {m*5} 分钟 +1 分",
                                     "affected": len(hiders), "at": C.now()}))
            if elapsed >= dur:
                if phase == C.HIDING:
                    c.execute(
                        "UPDATE games SET status=?, phase_started_at=? WHERE id=?",
                        (C.CHASING, C.now(), gid),
                    )
                    events.append((gid, {"type": "phase", "phase": C.CHASING,
                                         "text": "躲藏时间结束，抓捕阶段开始！"}))
                else:
                    winner = finish_game(c, gid)
                    events.append((gid, {"type": "game_over", "winner": winner,
                                         "text": "躲藏者获胜 🎉" if winner == "hiders" else "抓捕者获胜 🎯"}))
    return events


# ---------------------------------------------------------------- 道具球
def create_balls(c, game_id: str, count: int) -> list:
    out = []
    start = c.execute("SELECT COUNT(*) n FROM balls WHERE game_id=?", (game_id,)).fetchone()["n"]
    for i in range(count):
        code = make_ball_code()
        label = f"球 {start + i + 1:02d}"
        c.execute(
            "INSERT INTO balls(code,game_id,label,created_at) VALUES(?,?,?,?)",
            (code, game_id, label, C.now()),
        )
        out.append({"code": code, "label": label})
    return out


def nearby_hiders(c, game_id: str, lat: float, lng: float, range_m: float) -> list:
    rows = c.execute(
        "SELECT lp.user_id, lp.lat, lp.lng, lp.updated_at, u.display_name "
        "FROM live_positions lp JOIN game_players gp ON gp.game_id=lp.game_id AND gp.user_id=lp.user_id "
        "JOIN users u ON u.id=lp.user_id "
        "WHERE lp.game_id=? AND lp.kind='real' AND gp.role=? AND gp.alive=1",
        (game_id, C.HIDER),
    ).fetchall()
    found = []
    for r in rows:
        d = haversine_m(lat, lng, r["lat"], r["lng"])
        if d <= range_m:
            found.append({"dist_m": round(d, 1), "sector": bearing_cn(lat, lng, r["lat"], r["lng"])})
    return found
