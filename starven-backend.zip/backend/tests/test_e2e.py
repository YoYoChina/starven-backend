"""端到端验收：逐条对照公告规则实跑一遍。

运行： cd backend && PYTHONPATH=. python3 -m pytest tests/test_e2e.py -q -s
"""
import math
import os
import tempfile
import time

os.environ["DATA_DIR"] = tempfile.mkdtemp(prefix="starven-e2e-")
os.environ["TICK_SECONDS"] = "3600"          # 关闭自动 tick，由测试手动推进时间
os.environ["BOOTSTRAP_ADMIN_PASSWORD"] = "TestAdmin123"
os.environ["BOOTSTRAP_INVITE_CODE"] = "TESTINVITE"

import pytest
from fastapi.testclient import TestClient

from app.db import conn
from app.game import allocate_roles, engine_tick
from app.main import app
from app.utils import make_player_code

CTX = {}
LAT, LNG = 33.0, 120.0


def H(token):
    return {"Authorization": "Bearer " + token}


def north(meters, east=0.0):
    return (LAT + meters / 111320,
            LNG + east / (111320 * math.cos(math.radians(LAT))))


@pytest.fixture(scope="module")
def c():
    with TestClient(app) as client:
        yield client


def test_00_health_and_meta(c):
    assert c.get("/api/health").json()["ok"] is True
    rules = c.get("/api/meta").json()["rules"]
    assert rules["min_players"] == 14
    assert rules["hide_minutes"] == 30 and rules["chase_minutes"] == 30
    assert rules["catch_score"] == 10 and rules["ball_score"] == 0.5
    assert rules["radar_range_m"] == 30


def test_01_login_and_register(c):
    bad = c.post("/api/auth/login", json={"username": "admin", "password": "wrong"})
    assert bad.status_code == 401
    r = c.post("/api/auth/login", json={"username": "admin", "password": "TestAdmin123"})
    assert r.status_code == 200
    admin = r.json()
    CTX["admin"] = admin["token"]
    assert admin["user"]["is_admin"] is True

    # 错误邀请码应拒绝
    assert c.post("/api/auth/register", json={
        "username": "nobody", "password": "password123",
        "display_name": "无关人员", "invite_code": "WRONG"}).status_code == 400

    codes = c.post("/api/auth/invites", json={"count": 20}, headers=H(CTX["admin"]))
    assert codes.status_code == 200
    invites = codes.json()["codes"]

    members = []
    for i in range(14):
        r = c.post("/api/auth/register", json={
            "username": f"u{i+1:02d}", "password": "password123",
            "display_name": f"成员{i+1:02d}", "invite_code": invites[i]})
        assert r.status_code == 200, r.text
        members.append({"id": r.json()["user"]["id"],
                        "username": f"u{i+1:02d}", "token": r.json()["token"]})
    CTX["members"] = members
    assert len(members) == 14
    # me + 修改密码 + 重新登录
    assert c.get("/api/auth/me", headers=H(members[0]["token"])).json()["user"]["username"] == "u01"
    assert c.post("/api/auth/password", json={"old_password": "password123",
                                              "new_password": "newpassword123"},
                  headers=H(members[0]["token"])).status_code == 200
    relog = c.post("/api/auth/login", json={"username": "u01", "password": "newpassword123"})
    assert relog.status_code == 200
    members[0]["token"] = relog.json()["token"]


def make_game(c, name):
    r = c.post("/api/admin/games", json={
        "name": name, "center_lat": LAT, "center_lng": LNG,
        "radius_m": 150, "hide_minutes": 30, "chase_minutes": 30}, headers=H(CTX["admin"]))
    assert r.status_code == 200, r.text
    g = r.json()["game"]
    for m in CTX["members"]:
        j = c.post("/api/games/join", json={"join_code": g["join_code"]}, headers=H(m["token"]))
        assert j.status_code == 200, j.text
    d = c.post(f"/api/admin/games/{g['id']}/draw", json={}, headers=H(CTX["admin"]))
    assert d.status_code == 200, d.text
    alloc = d.json()["alloc"]
    assert alloc == {"抓捕者": 1, "躲藏者": 10, "协助者": 3}, alloc
    board = c.get(f"/api/games/{g['id']}/leaderboard", headers=H(CTX["admin"])).json()["items"]
    roles = {"catcher": [], "hider": [], "assistant": []}
    for row in board:
        roles[row["role"]].append(row["user_id"])
    CTX.setdefault("roles", {})[g["id"]] = roles
    return g, roles


def report_all(c, g, roles, near_hider=None):
    """给全员上报真实定位：抓捕者在中心，1 名躲藏者在 20 米内，其余在 100 米外。"""
    for uid in roles["catcher"]:
        assert c.post(f"/api/games/{g['id']}/position",
                      json={"lat": LAT, "lng": LNG, "accuracy": 5},
                      headers=H(token_of(uid))).status_code == 200
    for i, uid in enumerate(roles["hider"]):
        d = 20 if (near_hider is None and i == 0) or uid == near_hider else 100
        lat, lng = north(d)
        c.post(f"/api/games/{g['id']}/position", json={"lat": lat, "lng": lng},
               headers=H(token_of(uid)))
    for uid in roles["assistant"]:
        lat, lng = north(50)
        c.post(f"/api/games/{g['id']}/position", json={"lat": lat, "lng": lng},
               headers=H(token_of(uid)))


def token_of(uid):
    return next(m["token"] for m in CTX["members"] if m["id"] == uid)


def test_02_min_players_guard(c):
    r = c.post("/api/admin/games", json={
        "name": "人数校验用", "center_lat": LAT, "center_lng": LNG}, headers=H(CTX["admin"]))
    g = r.json()["game"]
    c.post("/api/games/join", json={"join_code": g["join_code"]}, headers=H(CTX["members"][0]["token"]))
    res = c.post(f"/api/admin/games/{g['id']}/start", json={}, headers=H(CTX["admin"]))
    assert res.status_code == 400 and "≥14" in res.json()["detail"]
    assert allocate_roles(28) == {"catcher": 2, "hider": 20, "assistant": 6}


def test_03_ball_scan_and_radar(c):
    g, roles = make_game(c, "第一期趣味躲猫猫比赛 · 计分验收")
    CTX["gameA"] = g
    assert c.post(f"/api/admin/games/{g['id']}/start", json={}, headers=H(CTX["admin"])).status_code == 200
    report_all(c, g, roles)

    balls = c.post(f"/api/admin/games/{g['id']}/balls", json={"count": 10},
                   headers=H(CTX["admin"])).json()["items"]
    assert len(balls) == 10

    hider = roles["hider"][0]
    catcher = roles["catcher"][0]
    # 躲藏者扫球：发送随机错误定位 +0.5
    r = c.post(f"/api/games/{g['id']}/scan", json={"code": balls[0]["code"]}, headers=H(token_of(hider)))
    assert r.status_code == 200, r.text
    assert r.json()["kind"] == "hider_decoy" and r.json()["delta"] == 0.5
    assert r.json()["score"] == 0.5
    # 抓捕者雷达不应看到真实躲藏者
    radar = c.get(f"/api/games/{g['id']}/radar", headers=H(token_of(catcher))).json()
    assert all(p["kind"] != "real" for p in radar["points"]), "抓捕者不应拿到真实定位"
    assert any(p["kind"] == "decoy" for p in radar["points"]), "抓捕者应收到可疑信号"
    # 协助者可看全场真实定位
    radar_a = c.get(f"/api/games/{g['id']}/radar", headers=H(token_of(roles["assistant"][0]))).json()
    assert radar_a["privileged"] is True and len(radar_a["points"]) >= 10

    # 抓捕者扫球：30 米内查询 +0.5
    r = c.post(f"/api/games/{g['id']}/scan", json={"code": balls[1]["code"]}, headers=H(token_of(catcher)))
    assert r.status_code == 200, r.text
    assert r.json()["kind"] == "catcher_radar" and r.json()["delta"] == 0.5
    assert r.json()["count"] == 1 and r.json()["found"] is True, r.json()
    assert 0 < r.json()["sectors"][0]["dist_m"] <= 30

    # 同一颗球不能重复刷分；乱码拒绝
    assert c.post(f"/api/games/{g['id']}/scan", json={"code": balls[1]["code"]},
                  headers=H(token_of(catcher))).status_code == 400
    assert c.post(f"/api/games/{g['id']}/scan", json={"code": "NOT-A-CODE"},
                  headers=H(token_of(hider))).status_code == 400

    # 玩家身份码 / 二维码
    qr = c.get(f"/api/games/{g['id']}/my-qr", headers=H(token_of(hider))).json()
    assert qr["code"] == make_player_code(hider) and "<svg" in qr["svg"]


def test_04_survive_bonus_and_hiders_win(c):
    g = CTX["gameA"]
    roles = CTX["roles"][g["id"]]
    hider = roles["hider"][0]
    # 推进 5 分钟：躲藏者 +1，抓捕者不加
    before = c.get(f"/api/games/{g['id']}/leaderboard", headers=H(CTX["admin"])).json()["items"]
    h0 = next(x["score"] for x in before if x["user_id"] == hider)
    c0 = next(x["score"] for x in before if x["user_id"] == roles["catcher"][0])
    with conn() as db:
        db.execute("UPDATE games SET phase_started_at=? WHERE id=?", (time.time() - 310, g["id"]))
    engine_tick()
    after = c.get(f"/api/games/{g['id']}/leaderboard", headers=H(CTX["admin"])).json()["items"]
    assert next(x["score"] for x in after if x["user_id"] == hider) == h0 + 1
    assert next(x["score"] for x in after if x["user_id"] == roles["catcher"][0]) == c0

    # 躲藏 30 分钟到点 -> 自动切抓捕阶段
    with conn() as db:
        db.execute("UPDATE games SET phase_started_at=? WHERE id=?", (time.time() - 31 * 60, g["id"]))
    engine_tick()
    assert c.get(f"/api/games/{g['id']}/state", headers=H(CTX["admin"])).json()["clock"]["phase"] == "chasing"
    # 抓捕 30 分钟到点，仍有幸存者 -> 躲藏者获胜
    with conn() as db:
        db.execute("UPDATE games SET phase_started_at=? WHERE id=?", (time.time() - 31 * 60, g["id"]))
    engine_tick()
    st = c.get(f"/api/games/{g['id']}/state", headers=H(CTX["admin"])).json()
    assert st["clock"]["phase"] == "finished" and st["game"]["winner"] == "hiders"


def test_05_catch_and_catcher_win(c):
    g, roles = make_game(c, "第一期趣味躲猫猫比赛 · 胜负验收")
    assert c.post(f"/api/admin/games/{g['id']}/start", json={}, headers=H(CTX["admin"])).status_code == 200
    assert c.post(f"/api/admin/games/{g['id']}/next-phase", json={},
                  headers=H(CTX["admin"])).status_code == 200
    report_all(c, g, roles)
    catcher = roles["catcher"][0]
    # 抓捕者扫躲藏者身份码：每抓一人 +10
    for i, hider in enumerate(roles["hider"]):
        r = c.post(f"/api/games/{g['id']}/scan",
                   json={"code": make_player_code(hider)}, headers=H(token_of(catcher)))
        assert r.status_code == 200, r.text
        assert r.json()["delta"] == 10 and r.json()["score"] == 10 * (i + 1)
    st = c.get(f"/api/games/{g['id']}/state", headers=H(CTX["admin"])).json()
    assert st["clock"]["phase"] == "finished"
    assert st["game"]["winner"] == "catcher"          # 无幸存者 -> 抓捕者获胜
    assert st["counts"]["alive_hiders"] == 0


def test_06_websocket(c):
    g = CTX["gameA"]
    token = CTX["members"][0]["token"]
    with c.websocket_connect(f"/api/ws?token={token}&game_id={g['id']}") as ws:
        msg = ws.receive_json()
        assert msg["type"] == "hello"
        assert msg["uid"] == CTX["members"][0]["id"]
        ws.send_text("ping")
        assert ws.receive_json()["type"] == "pong"
