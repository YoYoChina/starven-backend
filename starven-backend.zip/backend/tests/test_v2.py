"""v2 验收：自定义倒计时 / 全程轨迹 / 地图双源 / 一键公开全员定位。

运行： cd backend && PYTHONPATH=. python3 -m pytest tests/test_v2.py -q
"""
import os
import tempfile
import time

os.environ["DATA_DIR"] = tempfile.mkdtemp(prefix="starven-v2-e2e-")
os.environ["TICK_SECONDS"] = "3600"
os.environ["BOOTSTRAP_ADMIN_PASSWORD"] = "TestAdmin123"
os.environ["BOOTSTRAP_INVITE_CODE"] = "TESTINVITE"

import pytest
from fastapi.testclient import TestClient

from app.countdown import countdown_tick
from app.db import conn
from app.main import app

CTX = {}
LAT, LNG = 33.348, 120.156


def H(token): return {"Authorization": "Bearer " + token}


@pytest.fixture(scope="module")
def c():
    with TestClient(app) as client:
        yield client


def setup_game(c, name="v2 验收赛"):
    token = c.post("/api/auth/login", json={"username": "admin", "password": "TestAdmin123"}).json()["token"]
    codes = c.post("/api/auth/invites", json={"count": 16}, headers=H(token)).json()["codes"]
    members = []
    for i in range(14):
        r = c.post("/api/auth/register", json={
            "username": f"v2u{i+1:02d}", "password": "password123",
            "display_name": f"成员{i+1:02d}", "invite_code": codes[i]})
        assert r.status_code == 200, r.text
        members.append({"id": r.json()["user"]["id"], "token": r.json()["token"]})
    g = c.post("/api/admin/games", json={
        "name": name, "center_lat": LAT, "center_lng": LNG, "radius_m": 150,
        "hide_minutes": 30, "chase_minutes": 30}, headers=H(token)).json()["game"]
    for m in members:
        assert c.post("/api/games/join", json={"join_code": g["join_code"]},
                      headers=H(m["token"])).status_code == 200
    assert c.post(f"/api/admin/games/{g['id']}/draw", json={}, headers=H(token)).status_code == 200
    assert c.post(f"/api/admin/games/{g['id']}/start", json={}, headers=H(token)).status_code == 200
    board = c.get(f"/api/games/{g['id']}/leaderboard", headers=H(token)).json()["items"]
    roles = {"catcher": [], "hider": [], "assistant": []}
    for row in board:
        roles[row["role"]].append(row["user_id"])
    return {"admin": token, "gid": g["id"], "members": members, "roles": roles}


def token_of(ctx, uid):
    return next(m["token"] for m in ctx["members"] if m["id"] == uid)


def test_00_health_v2(c):
    h = c.get("/api/health").json()
    assert h["edition"] == "v2-map-countdown"
    v2 = c.get("/api/meta").json()["v2"]
    assert "countdown" in v2 and "map" in v2 and "reveal" in v2
    assert "gaode" in v2["tiles"] and "none" in v2["tiles"]


def test_01_countdown_segments_and_sequential(c):
    ctx = setup_game(c, "倒计时验收")
    CTX["game"] = ctx
    gid, admin = ctx["gid"], ctx["admin"]

    st = c.get(f"/api/games/{gid}/countdown", headers=H(admin)).json()
    assert st["segment_count"] == 3 and st["mode"] == "sequential"

    # 自定义：改成 4 段，10 秒一段，验证段数自由
    r = c.put(f"/api/admin/games/{gid}/countdown/segments", json={"segments": [
        {"label": "第一段", "duration": 10}, {"label": "第二段", "duration": 10},
        {"label": "第三段", "duration": 10}, {"label": "第四段", "duration": 10},
    ]}, headers=H(admin))
    assert r.status_code == 200 and r.json()["state"]["segment_count"] == 4
    assert c.post(f"/api/admin/games/{gid}/countdown/segments",
                  json={"label": "加时", "duration": 60}, headers=H(admin)).json()["state"]["segment_count"] == 5
    segs = c.get(f"/api/games/{gid}/countdown", headers=H(admin)).json()["items"]
    c.delete(f"/api/admin/games/{gid}/countdown/segments/{segs[-1]['id']}", headers=H(admin))

    # 顺序模式：启动后只有第一段 running
    r = c.post(f"/api/admin/games/{gid}/countdown/start", json={}, headers=H(admin)).json()
    assert len(r["state"]["active_ids"]) == 1
    first_id = r["state"]["active_ids"][0]

    # 把第一段结束时间推到过去 -> tick 后应自动启动第二段
    with conn() as db:
        db.execute("UPDATE countdowns SET ends_at=? WHERE id=?", (time.time() - 1, first_id))
    events = countdown_tick()
    assert any(e[0] == gid and "自动启动" in e[1].get("text", "") for e in events), events
    st = c.get(f"/api/games/{gid}/countdown", headers=H(admin)).json()
    assert st["active_id"] != first_id
    assert next(x for x in st["items"] if x["id"] == first_id)["status"] == "done"
    assert next(x for x in st["items"] if x["id"] == st["active_id"])["label"] == "第二段"

    # 暂停 / 继续 / 重置
    c.post(f"/api/admin/games/{gid}/countdown/pause", json={}, headers=H(admin))
    assert c.get(f"/api/games/{gid}/countdown", headers=H(admin)).json()["active_id"] is None
    c.post(f"/api/admin/games/{gid}/countdown/resume", json={}, headers=H(admin))
    assert c.get(f"/api/games/{gid}/countdown", headers=H(admin)).json()["active_id"] is not None
    c.post(f"/api/admin/games/{gid}/countdown/reset", json={}, headers=H(admin))
    assert all(x["status"] == "idle" for x in
               c.get(f"/api/games/{gid}/countdown", headers=H(admin)).json()["items"])


def test_02_countdown_parallel(c):
    ctx = CTX["game"]
    gid, admin = ctx["gid"], ctx["admin"]
    r = c.post(f"/api/admin/games/{gid}/countdown/mode", json={"mode": "parallel"}, headers=H(admin))
    assert r.json()["state"]["mode"] == "parallel"
    r = c.post(f"/api/admin/games/{gid}/countdown/start", json={}, headers=H(admin)).json()
    assert len(r["state"]["active_ids"]) == 4       # 四段同时显示、同时计时
    assert c.post(f"/api/admin/games/{gid}/countdown/next", json={},
                  headers=H(admin)).status_code == 400  # 同时模式没有「下一段」

    # 全部到期 -> all_done
    with conn() as db:
        db.execute("UPDATE countdowns SET ends_at=? WHERE game_id=? AND status='running'",
                   (time.time() - 1, gid))
    countdown_tick()
    st = c.get(f"/api/games/{gid}/countdown", headers=H(admin)).json()
    assert st["all_done"] is True and all(x["status"] == "done" for x in st["items"])


def test_03_tracks_and_privacy(c):
    ctx = CTX["game"]
    gid, admin, roles = ctx["gid"], ctx["admin"], ctx["roles"]
    hider, catcher = roles["hider"][0], roles["catcher"][0]
    ht, ct = token_of(ctx, hider), token_of(ctx, catcher)

    # 全员各上报 3 个轨迹点
    for uid in [hider, catcher] + roles["assistant"]:
        pts = [{"lat": LAT + i * 0.0001, "lng": LNG + i * 0.0001, "seq": i + 1,
                "accuracy": 8, "phase": "hiding"} for i in range(3)]
        r = c.post(f"/api/games/{gid}/track", json={"points": pts}, headers=H(token_of(ctx, uid)))
        assert r.status_code == 200 and r.json()["accepted"] == 3
    # 重发同一批：seq 去重，不产生重复轨迹
    pts = [{"lat": LAT, "lng": LNG, "seq": 1}, {"lat": LAT, "lng": LNG, "seq": 2}]
    r = c.post(f"/api/games/{gid}/track", json={"points": pts}, headers=H(ht))
    assert r.json()["accepted"] == 0 and r.json()["total"] == 3

    # 未公开：普通成员只能看自己的轨迹，也不能看别人
    mine = c.get(f"/api/games/{gid}/tracks", headers=H(ht)).json()
    assert mine["see_all"] is False and all(p["user_id"] == hider for p in mine["items"])
    assert c.get(f"/api/games/{gid}/tracks?user_id={catcher}", headers=H(ht)).status_code == 403
    # 抓捕者地图上没有真实躲藏者点
    m = c.get(f"/api/games/{gid}/map", headers=H(ct)).json()
    assert all(p["kind"] != "real" for p in m["points"])
    assert m["tiles"]["key"] == "osm" and m["tiles"]["crs"] == "WGS84"


def test_04_reveal_all(c):
    ctx = CTX["game"]
    gid, admin, roles = ctx["gid"], ctx["admin"], ctx["roles"]
    ht = token_of(ctx, roles["hider"][0])
    ct = token_of(ctx, roles["catcher"][0])

    assert c.post(f"/api/admin/games/{gid}/reveal", json={"enabled": True}, headers=H(admin)).json()["enabled"]
    m = c.get(f"/api/games/{gid}/map", headers=H(ct)).json()
    assert m["reveal_all"] is True and m["see_all"] is True
    assert any(p["kind"] == "real" for p in m["points"]), "公开后抓捕者也应看到真实点"
    tracks = c.get(f"/api/games/{gid}/tracks", headers=H(ht)).json()
    assert tracks["see_all"] is True and len({p["user_id"] for p in tracks["items"]}) >= 2
    radar = c.get(f"/api/games/{gid}/radar", headers=H(ct)).json()
    assert radar["reveal_all"] is True and radar["privileged"] is True

    assert c.post(f"/api/admin/games/{gid}/reveal", json={"enabled": False}, headers=H(admin)).json()["enabled"] is False
    assert c.get(f"/api/games/{gid}/map", headers=H(ct)).json()["see_all"] is False


def test_05_tiles_and_export(c):
    ctx = CTX["game"]
    gid, admin, roles = ctx["gid"], ctx["admin"], ctx["roles"]
    r = c.patch(f"/api/admin/games/{gid}/map-tiles", json={"tiles": "gaode"}, headers=H(admin))
    assert r.status_code == 200 and r.json()["crs"] == "GCJ02"
    m = c.get(f"/api/games/{gid}/map", headers=H(admin)).json()
    assert m["tiles"]["key"] == "gaode" and "{s}" in m["tiles"]["url"]
    assert c.patch(f"/api/admin/games/{gid}/map-tiles", json={"tiles": "tianditu"},
                   headers=H(admin)).status_code == 400   # 需要 tk

    geo = c.get(f"/api/admin/games/{gid}/tracks/export?format=geojson", headers=H(admin))
    assert geo.status_code == 200
    fc = geo.json()
    assert fc["type"] == "FeatureCollection" and len(fc["features"]) >= 1
    assert fc["features"][0]["geometry"]["type"] == "LineString"
    csv = c.get(f"/api/admin/games/{gid}/tracks/export?format=csv", headers=H(admin))
    assert csv.status_code == 200 and "display_name" in csv.text
    assert c.get(f"/api/admin/games/{gid}/tracks/export?format=csv",
                 headers=H(token_of(ctx, roles["hider"][0]))).status_code == 403



def test_06_geo_status(c):
    ctx = CTX["game"]
    gid, admin = ctx["gid"], ctx["admin"]
    s = c.get(f"/api/games/{gid}/geo-status", headers=H(admin)).json()
    assert s["tiles"]["key"] in ("gaode", "osm")
    assert isinstance(s["hints"], list) and len(s["hints"]) >= 3
    assert "server_now" in s and "ws_clients" in s
