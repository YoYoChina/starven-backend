# 星湾躲猫猫 APP · 网站后端包

> 这个包**只含后端 API**（FastAPI + SQLite + WebSocket），部署到已备案的 **`m.starven.cn`**。
> 前端 PWA 在另一个「GitHub 前端包」里，上传到 GitHub 后跨域调用本服务。
> 两个包独立部署、独立上传，不需要把对方的文件拖进来。

---

## 一、端口速查

| 层 | 地址 / 端口 |
|---|---|
| **对外 API** | **`https://m.starven.cn/api/`**（443，URL 不带端口） |
| Halo 前置 nginx | 监听 443，按 `server_name m.starven.cn` 反代到本机 8080；配置见 `nginx-m.starven.cn.conf` |
| 本机 | **8080** = API 容器（推荐）/ **8443** = HTTPS 直连备选 |
| 容器内网 | **8000** = FastAPI 真实监听 |

> 80/443 仍归 Halo，本项目不抢端口；前端页面**不在** m.starven.cn 上。

## 二、部署（3 步）

```bash
# 1. 解压进目录，一键启动（自动生成 .env / 构建 / 健康检查）
chmod +x deploy.sh
./deploy.sh

# 2. 把反代配置装到 Halo 前置 nginx
cp nginx-m.starven.cn.conf /etc/nginx/conf.d/m.starven.cn.conf
nginx -t && systemctl reload nginx

# 3. 验证
curl https://m.starven.cn/api/health
# → {"ok":true,"edition":"v2-map-countdown",...}
```

`.env` 里自动生成随机 `SECRET_KEY` 和管理员密码（权限 600）。**首次登录后立刻改密码**。
备选 `./deploy.sh https` 走 8443 直连，需要把证书放进 `certs/`。

## 三、和前端包怎么对上

| 项 | 位置 | 值 |
|---|---|---|
| 后端地址 | 前端包 `frontend/index.html` | `window.STARVEN_API_BASE = "https://m.starven.cn"` |
| 跨域白名单 | 后端包 `.env` | `CORS_ORIGINS=*`（默认可用）；上线后收紧成 `https://<用户名>.github.io` |
| 实时通道 | 自动 | `wss://m.starven.cn/api/ws`，反代需带 `Upgrade` 头（已配好） |

改 `.env` 后 `docker compose restart api` 生效。Mixed Content 是常见坑：前端是 HTTPS，后端地址必须也写 `https://`。

## 四、目录结构

```
星湾APP_网站后端/
├── backend/
│   ├── app/             FastAPI：账号 / 比赛 / 扫球 / 倒计时 / 地图轨迹 / 公开定位 / WebSocket
│   ├── tests/           14 项端到端测试
│   ├── Dockerfile       python:3.11-slim，容器内 8000
│   └── requirements.txt
├── docker-compose.yml           ★ 推荐：单容器 API，8080
├── docker-compose.https.yml     备选：nginx 终止 TLS，8443
├── nginx-tls.conf               8443 直连用
├── nginx-m.starven.cn.conf      ★ Halo 前置反代（443 → 8080）
├── deploy.sh                    一键部署
├── .env.example                 环境变量模板
├── certs/                       8443 直连时放证书
├── data/                        SQLite 数据库（自动创建，记得备份）
└── docs/
    ├── 部署与运维.md            ★ 端口、CORS、故障排查、安全
    └── 现场操作手册.md          11月21日当天的分部门 SOP
```

## 五、已验证

```
cd backend && PYTHONPATH=. python3 -m pytest tests/ -q  → 14 passed
两份 compose YAML 解析通过；deploy.sh bash -n 通过
```

> 沙盒里没有 Docker daemon，**镜像没有实际 build 过**；compose 已通过解析器校验，后端依赖与全量测试在本地 Python 环境实跑过。服务器上第一次 `up -d --build` 会拉 `python:3.11-slim`（8443 模式还会拉 `nginx:1.27-alpine`）。

## 六、如实说明

- 我没有你的服务器/GitHub 权限，交付的是可一键部署的项目，不是已上线的服务。
- 本包不含前端页面、不含 `.env` 里的真实密钥、不含证书私钥；`.gitignore` 已排除这些。
- 前端在 GitHub Pages 时属于跨域，靠 `CORS_ORIGINS` 放行；若把前端也放在 `m.starven.cn` 同源部署，则不需要 CORS，但那就回到「完整项目」那种单包模式了。

---

*为星湾之未来而奋斗 ✊*
