#!/usr/bin/env bash
# 星湾躲猫猫 · 后端一键安装
# 适用：阿里云轻量应用服务器（Docker CE）+ Halo 占用 80/443 的 Nginx
# 只需要：把这个包解压后执行  bash setup.sh
cd "$(dirname "$0")" || exit 1

ok()   { echo "✅ $*"; }
warn() { echo "⚠️  $*"; }
die()  { echo "❌ $*"; echo "   把上面这段红字截图发我即可，不用自己查。"; exit 1; }

echo ""
echo "=========================================="
echo "  星湾后端一键安装 · 开始（约 1-3 分钟）"
echo "=========================================="

# ---- 1. Docker ----
command -v docker >/dev/null 2>&1 || die "没找到 docker，请确认这台是 Docker CE 环境"
ok "Docker 正常"

# ---- 2. compose 插件 ----
if docker compose version >/dev/null 2>&1; then
  DC="docker compose"; ok "compose 插件正常"
elif command -v docker-compose >/dev/null 2>&1; then
  DC="docker-compose"; ok "检测到旧版 docker-compose，可继续使用"
else
  warn "缺 compose 插件，尝试自动安装..."
  if command -v yum >/dev/null 2>&1; then
    yum install -y docker-compose-plugin >/dev/null 2>&1
  elif command -v apt-get >/dev/null 2>&1; then
    apt-get update -qq >/dev/null 2>&1 && apt-get install -y docker-compose-plugin >/dev/null 2>&1
  fi
  if docker compose version >/dev/null 2>&1; then
    DC="docker compose"; ok "插件装好了"
  else
    die "compose 插件装不上，服务器可能不是标准 Docker CE 镜像"
  fi
fi

# ---- 3. 生成 .env（只生成一次，重跑不会覆盖） ----
if [ ! -f .env ]; then
  SECRET="$(openssl rand -hex 32 2>/dev/null || python3 -c 'import secrets;print(secrets.token_hex(32))')"
  PW="$(openssl rand -base64 24 2>/dev/null | tr -dc 'A-Za-z0-9' | cut -c1-16)"
  [ -z "$PW" ] && PW="Starven$(date +%s)"
  cat > .env <<EOF
APP_DOMAIN=m.starven.cn
CORS_ORIGINS=*
APP_PORT=8080
HTTPS_PORT=8443
SECRET_KEY=${SECRET}
ADMIN_USER=admin
ADMIN_PASSWORD=${PW}
INVITE_CODE=STARVEN2026
HIDE_MINUTES=30
CHASE_MINUTES=30
EOF
  chmod 600 .env
  ok "已生成 .env（随机密钥 + 管理员密码）"
else
  ok ".env 已存在，沿用原配置"
fi

# ---- 4. 起后端容器 ----
echo "→ 正在构建并启动（第一次要拉镜像，稍等）..."
$DC -f docker-compose.yml up -d --build || die "容器启动失败，运行  $DC -f docker-compose.yml logs  看日志"
for i in $(seq 1 30); do
  curl -fsS http://127.0.0.1:8080/api/health >/dev/null 2>&1 && break
  sleep 2
done
curl -fsS http://127.0.0.1:8080/api/health >/dev/null 2>&1 \
  || die "本机 8080 健康检查没过，运行  $DC -f docker-compose.yml logs  看日志"
ok "后端已跑起来（本机 8080，容器内网 8000）"

# ---- 5. 自动识别 Nginx 在哪，并装反代（只新增文件，不动 Halo 原配置） ----
NGINX_CT="$(docker ps --format '{{.Names}}\t{{.Image}}' 2>/dev/null | grep -i nginx | head -1 | cut -f1)"
UP="127.0.0.1:8080"

if [ -n "$NGINX_CT" ]; then
  ok "检测到 Nginx 跑在容器里：$NGINX_CT"
  UP="172.17.0.1:8080"
  DUMP="$(docker exec "$NGINX_CT" sh -c 'nginx -T 2>/dev/null' || true)"
else
  ok "Nginx 装在宿主机上"
  DUMP="$(nginx -T 2>/dev/null || true)"
fi

CERT="$(echo "$DUMP" | grep -m1 'ssl_certificate ' | awk '{print $2}' | tr -d ';')"
CERTKEY="$(echo "$DUMP" | grep -m1 'ssl_certificate_key' | awk '{print $2}' | tr -d ';')"
[ -z "$CERT" ] && CERT="/etc/letsencrypt/live/starven.cn/fullchain.pem"
[ -z "$CERTKEY" ] && CERTKEY="/etc/letsencrypt/live/starven.cn/privkey.pem"

sed -e "s#/etc/letsencrypt/live/starven.cn/fullchain.pem#${CERT}#g" \
    -e "s#/etc/letsencrypt/live/starven.cn/privkey.pem#${CERTKEY}#g" \
    -e "s#127.0.0.1:8080#${UP}#g" \
    nginx-m.starven.cn.conf > /tmp/m.starven.cn.conf

RELOAD_OK=0
if [ -n "$NGINX_CT" ]; then
  docker cp /tmp/m.starven.cn.conf "$NGINX_CT":/etc/nginx/conf.d/m.starven.cn.conf
  if docker exec "$NGINX_CT" nginx -t >/dev/null 2>&1; then
    docker exec "$NGINX_CT" nginx -s reload >/dev/null 2>&1 && RELOAD_OK=1
  else
    docker exec "$NGINX_CT" rm -f /etc/nginx/conf.d/m.starven.cn.conf
    docker exec "$NGINX_CT" nginx -s reload >/dev/null 2>&1 || true
  fi
elif [ -d /etc/nginx/conf.d ]; then
  cp /tmp/m.starven.cn.conf /etc/nginx/conf.d/m.starven.cn.conf
  if nginx -t >/dev/null 2>&1; then
    (systemctl reload nginx 2>/dev/null || nginx -s reload) >/dev/null 2>&1 && RELOAD_OK=1
  else
    rm -f /etc/nginx/conf.d/m.starven.cn.conf
    (systemctl reload nginx 2>/dev/null || nginx -s reload) >/dev/null 2>&1 || true
  fi
fi

if [ "$RELOAD_OK" = "1" ]; then
  ok "m.starven.cn 反代已装好（Halo 原配置一行没动，校验通过才 reload）"
else
  warn "反代配置没通过校验，已自动撤掉，Halo 完全没被改动"
  warn "多半是证书路径不对，把下面两行路径发我，我给你改好的一行命令"
fi

# ---- 6. 总结 ----
PW_SHOW="$(grep -E '^ADMIN_PASSWORD=' .env | cut -d= -f2)"
echo ""
echo "=========================================="
echo "  后端安装完成 🎉"
echo "------------------------------------------"
echo "  管理员：admin / ${PW_SHOW}"
echo "  接口地址：https://m.starven.cn/api/"
echo "  前端不用改，已经写死这个地址"
echo "  证书：${CERT}"
echo "  反代目标：${UP}"
echo "=========================================="
echo "  还差两件『网页上点一下』的事："
echo "   1) 阿里云 → 云解析 DNS → starven.cn 加一条 A 记录："
echo "      主机记录填 m，记录值填本机公网 IP"
echo "   2) 证书要覆盖 m.starven.cn。若现在这张只签了主域，"
echo "      去阿里云 SSL 证书控制台免费签一张 m.starven.cn（Nginx 版），"
echo "      把路径发我，我给你替换命令"
echo "  防火墙只放行 443，8080 不要对公网开"
echo "------------------------------------------"
echo "  验证：curl -k https://m.starven.cn/api/health"
echo "  看日志：$DC -f docker-compose.yml logs -f"
echo "  停止：$DC -f docker-compose.yml down"
echo "=========================================="
echo ""
